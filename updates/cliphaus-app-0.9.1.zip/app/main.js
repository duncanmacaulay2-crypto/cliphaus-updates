// Cliphaus – Hauptprozess. Alle Daten liegen als normale Ordner und JSON-Dateien
// im gewählten Cliphaus-Ordner (empfohlen: iCloud Drive, mit dem Team geteilt).
//
// Struktur:  Cliphaus/<Kunde>/<Projekt>/<Video>/{video.json, RAW/, EXPORT/, .comments/}
//            Cliphaus/<Kunde>/_kunde.json   (Accounts, Metricool-Link)
const { app, BrowserWindow, ipcMain, dialog, shell, clipboard, nativeImage } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

const ICLOUD = path.join(os.homedir(), 'Library', 'Mobile Documents', 'com~apple~CloudDocs');
const VIDEO_EXT = /\.(mp4|mov|m4v|webm)$/i;
let cfgPath, cfg = {}, win = null, watcher = null, dragIcon = null;

/* ---------- Config ---------- */
function loadCfg() {
  try { cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8')); } catch { cfg = {}; }
  // Ältere Version: ein einziger Ordner -> als erstes Team übernehmen
  if (!Array.isArray(cfg.workspaces)) {
    cfg.workspaces = cfg.root ? [{ id: 'ws1', root: cfg.root }] : [];
    cfg.active = cfg.workspaces[0] ? 'ws1' : null;
  }
  const act = [cfg.workspaces.find(w => w.id === cfg.active), ...cfg.workspaces].find(w => w && fs.existsSync(w.root)) || cfg.workspaces.find(w => w.id === cfg.active) || cfg.workspaces[0];
  cfg.active = act ? act.id : null;
  cfg.root = act ? act.root : undefined;
}
// Team-Ordner automatisch finden: jeder Ordner direkt in iCloud Drive mit einer _team.json
// (auch geteilte Ordner von anderen, sobald die Einladung angenommen ist).
async function discoverTeams() {
  if (!fs.existsSync(ICLOUD)) return 0;
  let added = 0;
  for (const d of await listDirs(ICLOUD)) {
    const root = path.join(ICLOUD, d);
    if (!fs.existsSync(path.join(root, '_team.json')) && !fs.existsSync(path.join(root, '._team.json.icloud'))) continue;
    if (cfg.workspaces.some(w => path.resolve(w.root) === path.resolve(root))) continue;
    cfg.workspaces.push({ id: 'ws' + Date.now().toString(36) + added, root });
    added++;
  }
  if (added) {
    if (!cfg.active) { cfg.active = cfg.workspaces[0].id; cfg.root = cfg.workspaces[0].root; startWatch(); }
    saveCfg();
  }
  return added;
}
// Jeder Team-Ordner bekommt eine _team.json, damit ihn alle Geräte automatisch erkennen.
async function ensureTeamFile(root) {
  try {
    const f = path.join(root, '_team.json');
    if (!fs.existsSync(f) && !fs.existsSync(path.join(root, '._team.json.icloud'))) {
      await writeJson(f, { name: path.basename(root).replace(/^Cliphaus /, '') || 'Team' });
    }
  } catch {}
}
async function teamName(root) {
  const t = await readJson(path.join(root, '_team.json'), null);
  return (t && t.name) || path.basename(root);
}
function locationOf(root) {
  const r = path.resolve(root);
  if (r.startsWith(path.resolve(ICLOUD) + path.sep) || r === path.resolve(ICLOUD)) return 'icloud';
  if (r.startsWith('/Volumes/')) return 'extern';
  return 'mac';
}
async function teamsInfo() {
  const out = [];
  for (const w of cfg.workspaces) {
    const available = fs.existsSync(w.root);
    out.push({ id: w.id, root: w.root, name: available ? await teamName(w.root) : (w.name || path.basename(w.root)), location: locationOf(w.root), available });
  }
  return out;
}
function activate(id) {
  const w = cfg.workspaces.find(x => x.id === id); if (!w) throw new Error('Team nicht gefunden.');
  if (!fs.existsSync(w.root)) throw new Error(locationOf(w.root) === 'extern' ? 'Die Festplatte mit diesem Team ist nicht angeschlossen.' : 'Der Ordner dieses Teams wurde nicht gefunden.');
  cfg.active = w.id; cfg.root = w.root; lastOverview = ''; saveCfg(); startWatch();
  ensureTeamFile(w.root);
}
function saveCfg() { fs.mkdirSync(path.dirname(cfgPath), { recursive: true }); fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2)); }

/* ---------- Helpers ---------- */
const safeName = s => String(s || '').replace(/[\/\\:*?"<>|]+/g, '-').replace(/^\.+/, '').replace(/\s+/g, ' ').trim().slice(0, 120);
// Ordner von Kunden, die auf eine Festplatte ausgelagert sind (aus der letzten Suche)
let extRoots = new Set();
function inRoot(p) {
  if (!cfg.root) throw new Error('Kein Cliphaus-Ordner gewählt.');
  const x = path.resolve(p);
  for (const base of [cfg.root, ...extRoots]) {
    const r = path.resolve(base);
    if (x === r || x.startsWith(r + path.sep)) return x;
  }
  throw new Error('Pfad liegt außerhalb des Cliphaus-Ordners.');
}
async function exists(p) { try { await fsp.access(p); return true; } catch { return false; } }
async function readJson(p, fb) { try { return JSON.parse(await fsp.readFile(p, 'utf8')); } catch { return fb; } }
async function writeJson(p, data) {
  const tmp = path.join(path.dirname(p), '.' + path.basename(p) + '.tmp');
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  await fsp.rename(tmp, p);
}
async function listDirs(p) {
  try {
    return (await fsp.readdir(p, { withFileTypes: true }))
      .filter(d => d.isDirectory() && !d.name.startsWith('.') && !d.name.startsWith('_'))
      .map(d => d.name).sort((a, b) => a.localeCompare(b, 'de'));
  } catch { return []; }
}
// Listet Dateien rekursiv. Erkennt iCloud-Dateien, die noch nicht auf dem Mac liegen
// (".name.icloud"-Platzhalter oder "dataless" Dateien ohne belegte Blöcke).
async function listFiles(dir, rel = '') {
  let out = [], ents;
  try { ents = await fsp.readdir(path.join(dir, rel), { withFileTypes: true }); } catch { return out; }
  for (const d of ents) {
    const r = path.join(rel, d.name);
    if (d.isDirectory()) { if (!d.name.startsWith('.')) out = out.concat(await listFiles(dir, r)); continue; }
    let name = d.name, local = true, size = 0, mtime = 0;
    const m = name.match(/^\.(.+)\.icloud$/);
    if (m) { name = m[1]; local = false; } else if (name.startsWith('.')) continue;
    try {
      const st = await fsp.stat(path.join(dir, r));
      mtime = st.mtimeMs;
      if (local) { size = st.size; if (st.size > 0 && st.blocks === 0) local = false; }
    } catch {}
    const relName = path.join(path.dirname(r), name);
    out.push({ rel: relName, path: path.join(dir, relName), size, local, mtime });
  }
  return out;
}
async function scanVideo(vp, name) {
  const data = await readJson(path.join(vp, 'video.json'), {});
  const raw = await listFiles(path.join(vp, 'RAW'));
  const exports = (await listFiles(path.join(vp, 'EXPORT'))).filter(f => VIDEO_EXT.test(f.rel)).sort((a, b) => a.mtime - b.mtime);
  const comments = [];
  const cdir = path.join(vp, '.comments');
  try {
    for (const f of await fsp.readdir(cdir)) {
      if (!f.endsWith('.json') || f.startsWith('.')) continue;
      const c = await readJson(path.join(cdir, f), null);
      if (c) comments.push({ ...c, id: f.slice(0, -5) });
    }
  } catch {}
  const finals = (await listFiles(path.join(vp, 'FINAL'))).filter(f => VIDEO_EXT.test(f.rel)).sort((a, b) => a.mtime - b.mtime);
  const IMG = /\.(png|jpe?g|heic|webp|gif)$/i;
  const moodboard = (await listFiles(path.join(vp, 'MOODBOARD'))).filter(f => IMG.test(f.rel)).sort((a, b) => a.mtime - b.mtime);
  const storyboard = (await listFiles(path.join(vp, 'STORYBOARD'))).filter(f => IMG.test(f.rel));
  return { path: vp, folder: name, data, raw, exports, finals, moodboard, storyboard, comments };
}
async function scan() {
  if (!cfg.root) return null;
  if (!fs.existsSync(cfg.root)) return { clients: [], missing: true, location: locationOf(cfg.root) };
  const clients = [];
  const ext = new Set();
  for (const c of await listDirs(cfg.root)) {
    const cp = path.join(cfg.root, c);
    const projects = [];
    // Ausgelagerter Kunde: in iCloud liegt nur ein Platzhalter mit _extern.json
    const ex = await readJson(path.join(cp, '_extern.json'), null);
    let dataPath = cp, external = null;
    if (ex && ex.path) {
      const available = fs.existsSync(ex.path);
      external = { path: ex.path, volume: ex.volume || path.basename(ex.path), available };
      if (!available) { clients.push({ name: c, path: cp, dataPath: ex.path, external, meta: await readJson(path.join(cp, '_kunde.json'), {}), projects }); continue; }
      dataPath = ex.path; ext.add(ex.path);
    }
    for (const p of await listDirs(dataPath)) {
      const pp = path.join(dataPath, p);
      const videos = [];
      for (const v of await listDirs(pp)) videos.push(await scanVideo(path.join(pp, v), v));
      projects.push({ name: p, path: pp, videos });
    }
    clients.push({ name: c, path: cp, dataPath, external, meta: await readJson(path.join(cp, '_kunde.json'), {}), projects });
  }
  const changed = ext.size !== extRoots.size || [...ext].some(x => !extRoots.has(x));
  extRoots = ext;
  if (changed) startWatch();
  return { clients };
}
/* ---------- Handy-Übersicht (statische HTML-Datei im iCloud-Ordner) ---------- */
const STAGES = [['idee', 'Idee'], ['skript', 'Skript'], ['dreh', 'Dreh'], ['schnitt', 'Schnitt'], ['review', 'Review'], ['frei', 'Freigegeben'], ['gepostet', 'Gepostet']];
const STAGE_COL = ['#8A90AA', '#7E57C9', '#C27A12', '#3245D6', '#C4417A', '#1D8657', '#151A2F'];
const OVERVIEW_NAME = 'Cliphaus Übersicht.html';
let lastOverview = '';
const h = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ddmm = s => s ? s.slice(8, 10) + '.' + s.slice(5, 7) + '.' : '';
function sizeStr(b) { return b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(b ? 1 : 0, Math.round(b / 1e6)) + ' MB'; }
function overviewHtml(tree) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const days = s => s ? Math.round((new Date(s.slice(0, 10) + 'T00:00') - today) / 864e5) : null;
  let body = '';
  for (const c of tree.clients) {
    const n = c.projects.reduce((s, p) => s + p.videos.length, 0);
    if (c.external) { body += `<section><h2>${h(c.name)}</h2><p class="acc">Liegt auf der Festplatte „${h(c.external.volume)}“ (nur am Mac)</p></section>`; continue; }
    body += `<section><h2>${h(c.name)}</h2><p class="acc">${h([c.meta.instagram && 'IG ' + c.meta.instagram, c.meta.tiktok && 'TikTok ' + c.meta.tiktok].filter(Boolean).join(' · ') || n + ' Videos')}</p>`;
    for (const p of c.projects) {
      const done = p.videos.filter(v => ['frei', 'gepostet'].includes(v.data.stage)).length;
      body += `<div class="proj"><div class="ph"><b>${h(p.name)}</b><span>${done}/${p.videos.length} fertig</span></div>`;
      if (!p.videos.length) body += '<p class="muted">Noch keine Videos</p>';
      for (const v of p.videos) {
        const d = v.data || {}; const ix = Math.max(0, STAGES.findIndex(s => s[0] === (d.stage || 'idee')));
        const shots = d.shots || []; const sd = shots.filter(s => s.done).length;
        let dl = '';
        const pick = ix <= 2 && d.shootDate ? ['Dreh', d.shootDate] : ix <= 4 && d.dueDate ? ['Abgabe', d.dueDate] : ix <= 5 && d.postAt ? ['Post', d.postAt] : null;
        if (pick) { const x = days(pick[1]); dl = `<span class="dl ${x < 0 ? 'late' : x <= 2 ? 'soon' : ''}">${pick[0]} ${x < 0 ? -x + ' T. überfällig' : x === 0 ? 'heute' : x === 1 ? 'morgen' : ddmm(pick[1])}</span>`; }
        const open = v.comments.filter(x => !x.done).length;
        const caps = ['instagram', 'tiktok'].filter(k => (d.captions || {})[k]).map(k => `<p class="cap"><b>${k === 'instagram' ? 'Instagram' : 'TikTok'}</b><br>${h(d.captions[k]).replace(/\n/g, '<br>')}</p>`).join('');
        body += `<div class="vid"><div class="vt"><b>${d.type === 'referenz' ? '🔗 ' : ''}${h(d.title || v.folder)}</b><span class="st" style="background:${STAGE_COL[ix]}">${STAGES[ix][1]}</span></div>
          <div class="steps">${STAGES.map((s, i) => `<i style="background:${i <= ix ? STAGE_COL[ix] : 'var(--line)'}"></i>`).join('')}</div>
          <div class="meta">${dl}${shots.length ? `<span>${sd}/${shots.length} Shots</span>` : ''}<span>${v.raw.length ? v.raw.length + ' Raw · ' + sizeStr(v.raw.reduce((s, f) => s + f.size, 0)) : 'Noch kein Raw'}</span>${v.exports.length ? `<span>v${v.exports.length}</span>` : ''}${open ? `<span>${open} offene Kommentare</span>` : ''}${d.approval && d.approval.state === 'approved' ? '<span class="ok">freigegeben</span>' : d.approval && d.approval.state === 'changes' ? '<span class="late">Änderungen nötig</span>' : ''}</div>
          ${(d.references || []).length || d.notes ? `<details><summary>Referenzen &amp; Notizen</summary>${(d.references || []).map(r => `<p class="path"><a href="${h(r.url)}">${h(r.url)}</a>${r.note ? '<br>' + h(r.note) : ''}</p>`).join('')}${d.notes ? `<p class="cap">${h(d.notes).replace(/\n/g, '<br>')}</p>` : ''}</details>` : ''}
          <details><summary>Hochladen &amp; Captions</summary><p class="path">Raw hochladen nach:<br><b>Cliphaus › ${h(c.name)} › ${h(p.name)} › ${h(v.folder)} › RAW</b></p>${v.exports.length ? `<p class="path">Finale Datei zum Posten:<br><b>… › ${h(v.folder)} › EXPORT › ${h(v.exports[v.exports.length - 1].rel)}</b></p>` : ''}${caps || '<p class="muted">Noch keine Captions</p>'}</details></div>`;
      }
      body += '</div>';
    }
    body += '</section>';
  }
  const stamp = new Date().toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  return `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cliphaus Übersicht</title><style>
:root{--bg:#F1F2F7;--card:#fff;--ink:#151A2F;--muted:#5B6280;--line:#D6D9E6;--late:#D23A3A;--soon:#A9701A;--ok:#1D8657}
@media (prefers-color-scheme:dark){:root{--bg:#0E1120;--card:#171B2E;--ink:#E6E8F3;--muted:#99A0BE;--line:#2C3252;--late:#FF6D6D;--soon:#E3B04F;--ok:#4FC48C}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.4 -apple-system,system-ui,sans-serif;padding:16px 14px 40px}
h1{font-size:26px;margin:4px 0 2px;letter-spacing:-.02em}.stamp{color:var(--muted);font-size:13px;margin:0 0 18px}
h2{font-size:20px;margin:22px 0 0}.acc{color:var(--muted);font-size:13px;margin:2px 0 10px}
.proj{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px;margin-bottom:12px}
.ph{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px}.ph span{color:var(--muted);font-size:13px}
.vid{border-top:1px solid var(--line);padding:10px 0 8px}.vt{display:flex;justify-content:space-between;gap:8px;align-items:center}
.st{color:#fff;font-size:12px;font-weight:700;border-radius:999px;padding:3px 9px;white-space:nowrap}
.steps{display:grid;grid-template-columns:repeat(7,1fr);gap:3px;margin:8px 0}.steps i{height:5px;border-radius:3px}
.meta{display:flex;flex-wrap:wrap;gap:6px;font-size:12.5px;color:var(--muted)}.meta span{background:var(--bg);border-radius:6px;padding:2px 7px}
.late{color:var(--late)!important;font-weight:700}.soon{color:var(--soon)!important;font-weight:700}.ok{color:var(--ok)!important;font-weight:700}
details{margin-top:8px}summary{color:var(--muted);font-size:13px;font-weight:600}.path,.cap{font-size:13px;margin:8px 0;background:var(--bg);border-radius:8px;padding:8px;-webkit-user-select:text;user-select:text}
.muted{color:var(--muted);font-size:13px}</style></head><body><h1>Cliphaus</h1><p class="stamp">Stand: ${stamp} · aktualisiert sich, sobald ein Mac mit Cliphaus läuft</p>${body || '<p class="muted">Noch keine Kunden angelegt.</p>'}</body></html>`;
}
async function writeOverview(tree) {
  if (!tree || !cfg.root) return;
  const html = overviewHtml(tree);
  const key = html.replace(/Stand: [^·]*·/, '');
  if (key === lastOverview) return;
  lastOverview = key;
  try { await fsp.writeFile(path.join(cfg.root, OVERVIEW_NAME), html); } catch {}
}
function brctl(cmd, p) {
  return new Promise(res => execFile('/usr/bin/brctl', [cmd, p], () => res()));
}
let extWatchers = [];
function startWatch() {
  if (watcher) { try { watcher.close(); } catch {} watcher = null; }
  extWatchers.forEach(w => { try { w.close(); } catch {} }); extWatchers = [];
  if (!cfg.root) return;
  let t = null;
  const ping = () => { clearTimeout(t); t = setTimeout(() => win && !win.isDestroyed() && win.webContents.send('changed'), 400); };
  try { watcher = fs.watch(cfg.root, { recursive: true }, ping); } catch {}
  for (const r of extRoots) { try { extWatchers.push(fs.watch(r, { recursive: true }, ping)); } catch {} }
}

/* ---------- IPC ---------- */
function handle(name, fn) {
  ipcMain.handle(name, async (_e, ...args) => {
    try { return { ok: true, value: await fn(...args) }; }
    catch (err) { return { ok: false, error: String(err && err.message || err) }; }
  });
}
handle('state', async () => { await discoverTeams(); if (cfg.root) await ensureTeamFile(cfg.root); return { cfg, teams: await teamsInfo(), icloud: fs.existsSync(ICLOUD), icloudPath: ICLOUD, tree: await scan() }; });
handle('teams', async () => { await discoverTeams(); return teamsInfo(); });
// Team hinzufügen: entweder neu in iCloud Drive anlegen (create) oder vorhandenen (geteilten) Ordner übernehmen.
// location: 'icloud' (iCloud Drive), 'mac' (Dokumente auf diesem Mac) oder 'choose' (Ort selbst wählen, z. B. externe Festplatte)
handle('addTeam', async ({ root, name, create, location }) => {
  let dir = root;
  if (create) {
    const n = safeName(name); if (!n) throw new Error('Bitte einen Teamnamen eingeben.');
    let base;
    if (location === 'mac') base = path.join(os.homedir(), 'Documents');
    else if (location === 'choose') {
      const r = await dialog.showOpenDialog(win, { title: 'Wo soll das Team gespeichert werden?', defaultPath: fs.existsSync('/Volumes') ? '/Volumes' : os.homedir(), properties: ['openDirectory', 'createDirectory'], buttonLabel: 'Hier speichern' });
      if (r.canceled) return null;
      base = r.filePaths[0];
    } else base = fs.existsSync(ICLOUD) ? ICLOUD : os.homedir();
    dir = path.join(base, 'Cliphaus ' + n);
    if (fs.existsSync(dir)) throw new Error(`Den Ordner „Cliphaus ${n}“ gibt es dort schon. Wähle ihn über „Vorhandenen Ordner wählen“.`);
    await fsp.mkdir(dir, { recursive: true });
    await writeJson(path.join(dir, '_team.json'), { name: String(name).trim() });
  }
  if (!dir) throw new Error('Kein Ordner gewählt.');
  const existing = cfg.workspaces.find(w => path.resolve(w.root) === path.resolve(dir));
  if (existing) { activate(existing.id); return existing.id; }
  const id = 'ws' + Date.now().toString(36);
  cfg.workspaces.push({ id, root: dir, name: await teamName(dir) });
  activate(id);
  return id;
});
handle('switchTeam', async id => { activate(id); return true; });
handle('renameTeam', async (id, name) => {
  const w = cfg.workspaces.find(x => x.id === id); if (!w) throw new Error('Team nicht gefunden.');
  const t = await readJson(path.join(w.root, '_team.json'), {});
  await writeJson(path.join(w.root, '_team.json'), { ...t, name: String(name).trim() });
  return true;
});
handle('removeTeam', async id => {
  cfg.workspaces = cfg.workspaces.filter(w => w.id !== id);
  const next = cfg.workspaces[0];
  if (cfg.active === id) { cfg.active = next ? next.id : null; cfg.root = next ? next.root : undefined; }
  saveCfg(); startWatch(); return true;
});
handle('scan', async () => { const t = await scan(); writeOverview(t); return t; });
handle('setup', async ({ root, name }) => {
  if (root) {
    await fsp.mkdir(root, { recursive: true });
    let w = cfg.workspaces.find(x => path.resolve(x.root) === path.resolve(root));
    if (!w) { w = { id: 'ws' + Date.now().toString(36), root }; cfg.workspaces.push(w); }
    cfg.active = w.id; cfg.root = root;
  }
  if (name !== undefined) cfg.name = String(name).trim().slice(0, 60);
  saveCfg(); startWatch(); return cfg;
});
handle('chooseRoot', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Cliphaus-Ordner wählen', defaultPath: fs.existsSync(ICLOUD) ? ICLOUD : os.homedir(),
    properties: ['openDirectory', 'createDirectory'], buttonLabel: 'Diesen Ordner nutzen'
  });
  return r.canceled ? null : r.filePaths[0];
});
handle('mkClient', async name => {
  const n = safeName(name); if (!n) throw new Error('Bitte einen Namen eingeben.');
  const p = inRoot(path.join(cfg.root, n));
  if (await exists(p)) throw new Error(`Den Kunden „${n}“ gibt es schon.`);
  await fsp.mkdir(p, { recursive: true });
  await writeJson(path.join(p, '_kunde.json'), { instagram: '', tiktok: '', metricool: '', notes: '' });
  return p;
});
handle('mkProject', async (cp, name) => {
  const n = safeName(name); if (!n) throw new Error('Bitte einen Namen eingeben.');
  const p = inRoot(path.join(inRoot(cp), n));
  if (await exists(p)) throw new Error(`Das Projekt „${n}“ gibt es schon.`);
  await fsp.mkdir(p, { recursive: true }); return p;
});
handle('mkVideo', async (pp, title, type) => {
  const kind = ['referenz', 'kreativ'].includes(type) ? type : 'skript';
  const n = safeName(title); if (!n) throw new Error('Bitte einen Titel eingeben.');
  const p = inRoot(path.join(inRoot(pp), n));
  if (await exists(p)) throw new Error(`Das Video „${n}“ gibt es in diesem Projekt schon.`);
  for (const sub of ['RAW', 'EXPORT', 'FINAL', '.comments', ...(kind === 'kreativ' ? ['MOODBOARD', 'STORYBOARD'] : [])]) await fsp.mkdir(path.join(p, sub), { recursive: true });
  await writeJson(path.join(p, 'video.json'), {
    title: n, type: kind, references: [], notes: '', screenplay: '', scenes: [], moodboard: { colors: [], notes: '' }, canva: '', stage: 'idee', script: '', shots: [], shootDate: '', dueDate: '', postAt: '', assignee: '',
    captions: { instagram: '', tiktok: '' }, platforms: { instagram: true, tiktok: true },
    createdAt: new Date().toISOString(), createdBy: cfg.name || ''
  });
  return p;
});
handle('rename', async (p, newName) => {
  const src = inRoot(p); const n = safeName(newName); if (!n) throw new Error('Bitte einen Namen eingeben.');
  const dst = inRoot(path.join(path.dirname(src), n));
  if (dst === src) return dst;
  if (await exists(dst)) throw new Error(`„${n}“ gibt es hier schon.`);
  await fsp.rename(src, dst); return dst;
});
// Speichern mit Schutz: Hat ein Shot in der gespeicherten Datei schon ein Bild, das hier fehlt
// (z. B. weil das iPhone es gerade eingefügt hat und iCloud noch nicht fertig war), bleibt es erhalten.
handle('saveVideo', async (vp, data) => {
  const f = path.join(inRoot(vp), 'video.json');
  const old = await readJson(f, null);
  if (old && Array.isArray(old.scenes) && Array.isArray(data.scenes)) {
    const imgs = {};
    for (const s of old.scenes) if (s && s.id && s.img) imgs[s.id] = s.img;
    data = { ...data, scenes: data.scenes.map(s => (s && s.id && !s.img && imgs[s.id]) ? { ...s, img: imgs[s.id] } : s) };
  }
  await writeJson(f, data); return true;
});
handle('saveClient', async (cp, meta) => { await writeJson(path.join(inRoot(cp), '_kunde.json'), meta); return true; });
handle('saveComment', async (vp, c) => {
  const id = String(c.id || Date.now().toString(36) + Math.random().toString(36).slice(2, 6)).replace(/[^a-z0-9_-]/gi, '');
  const dir = path.join(inRoot(vp), '.comments'); await fsp.mkdir(dir, { recursive: true });
  const { id: _drop, ...rest } = c;
  await writeJson(path.join(dir, id + '.json'), rest); return id;
});
handle('revealTeam', async p => {
  if (!cfg.workspaces.some(w => path.resolve(w.root) === path.resolve(p))) throw new Error('Unbekannter Team-Ordner.');
  await shell.openPath(p); return true;
});
handle('trash', async p => { await shell.trashItem(inRoot(p)); return true; });
handle('reveal', async p => { const x = inRoot(p); if ((await fsp.stat(x)).isDirectory()) await shell.openPath(x); else shell.showItemInFolder(x); return true; });
handle('openUrl', async url => { if (!/^https:\/\//i.test(url)) throw new Error('Nur https-Links können geöffnet werden.'); await shell.openExternal(url); return true; });
handle('copy', async text => { clipboard.writeText(String(text)); return true; });
handle('download', async paths => { for (const p of paths) await brctl('download', inRoot(p)); return true; });
handle('evict', async paths => { for (const p of paths) await brctl('evict', inRoot(p)); return true; });
handle('importFiles', async (vp, sub, sources) => {
  const dest = inRoot(path.join(inRoot(vp), sub));
  await fsp.mkdir(dest, { recursive: true });
  let n = 0;
  for (const s of sources) {
    const target = path.join(dest, path.basename(s));
    if (path.resolve(s) === path.resolve(target)) continue;
    await fsp.cp(s, target, { recursive: true, force: false, errorOnExist: false });
    n++;
  }
  return n;
});
// Captions-App mit einer Videodatei öffnen
handle('openInCaptions', async file => {
  const f = inRoot(file);
  await new Promise((res, rej) => execFile('/usr/bin/open', ['-a', 'Captions', f], err => err ? rej(new Error('Die App „Captions“ wurde auf diesem Mac nicht gefunden. Installiere sie aus dem App Store oder öffne die Datei über „Im Finder“.')) : res()));
  return true;
});
// Dateien wählen (Bilder fürs Moodboard, finale Videos)
handle('pickFiles', async ({ kind, multi }) => {
  const filters = kind === 'image' ? [{ name: 'Bilder', extensions: ['png', 'jpg', 'jpeg', 'heic', 'webp', 'gif'] }] : [{ name: 'Videos', extensions: ['mp4', 'mov', 'm4v'] }];
  const r = await dialog.showOpenDialog(win, { properties: ['openFile', ...(multi ? ['multiSelections'] : [])], filters });
  return r.canceled ? [] : r.filePaths;
});
// Eine Datei unter festem Namen ablegen (z. B. Szenenbild)
handle('importAs', async (vp, sub, src, name) => {
  const dir = inRoot(path.join(inRoot(vp), sub));
  await fsp.mkdir(dir, { recursive: true });
  const target = inRoot(path.join(dir, safeName(name)));
  await fsp.copyFile(src, target);
  return target;
});
handle('removeFile', async p => { await shell.trashItem(inRoot(p)); return true; });
// Szenenliste als CSV für Canva „Bulk Create“
handle('writeCanvaCsv', async (vp, rows) => {
  const esc = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const head = ['Szene', 'Titel', 'Ort', 'Einstellung', 'Dauer', 'Beschreibung', 'Dialog / Ton'];
  const csv = '\ufeff' + [head, ...rows].map(r => r.map(esc).join(',')).join('\r\n');
  const f = inRoot(path.join(inRoot(vp), 'Storyboard für Canva.csv'));
  await fsp.writeFile(f, csv, 'utf8');
  shell.showItemInFolder(f);
  return f;
});
/* ---------- Lokale KI über Ollama (läuft auf diesem Mac) ---------- */
const OLLAMA = 'http://127.0.0.1:11434';
const DEFAULT_MODEL = 'gemma3:12b';
let aiAbort = null;
handle('aiStatus', async () => {
  const model = cfg.aiModel || DEFAULT_MODEL;
  try {
    const r = await fetch(OLLAMA + '/api/tags', { signal: AbortSignal.timeout(2500) });
    if (!r.ok) return { running: false, model };
    const j = await r.json();
    return { running: true, model, models: (j.models || []).map(x => x.name) };
  } catch { return { running: false, model }; }
});
handle('aiSetModel', async name => { cfg.aiModel = String(name || DEFAULT_MODEL); saveCfg(); return cfg.aiModel; });
handle('aiCancel', async () => { if (aiAbort) aiAbort.abort(); aiAbort = null; return true; });
handle('aiGenerate', async ({ system, prompt }) => {
  if (aiAbort) aiAbort.abort();
  const ctrl = new AbortController(); aiAbort = ctrl;
  const model = cfg.aiModel || DEFAULT_MODEL;
  let r;
  try {
    r = await fetch(OLLAMA + '/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctrl.signal,
      body: JSON.stringify({ model, stream: true, options: { temperature: 0.6 }, messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }] })
    });
  } catch (e) {
    if (ctrl.signal.aborted) throw new Error('Abgebrochen.');
    throw new Error('Ollama läuft nicht. Öffne die App „Ollama“ und versuch es nochmal.');
  }
  if (!r.ok) {
    const t = await r.text().catch(() => '');
    throw new Error(r.status === 404 || /not found/i.test(t) ? `Das Modell „${model}“ ist nicht installiert. Im Terminal: ollama pull ${model}` : 'Ollama meldet einen Fehler: ' + t.slice(0, 200));
  }
  const reader = r.body.getReader(); const dec = new TextDecoder();
  let buf = '', out = '';
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line) continue;
        let j; try { j = JSON.parse(line); } catch { continue; }
        if (j.error) throw new Error('Ollama: ' + j.error);
        const c = (j.message && j.message.content) || '';
        if (c) { out += c; if (win && !win.isDestroyed()) win.webContents.send('ai-chunk', out); }
      }
    }
  } catch (e) {
    if (ctrl.signal.aborted) throw new Error('Abgebrochen.');
    throw e;
  } finally { if (aiAbort === ctrl) aiAbort = null; }
  return out;
});
/* ---------- Kunde auf Festplatte auslagern / zurückholen ---------- */
function sendMove(text) { if (win && !win.isDestroyed()) win.webContents.send('move-progress', text); }
// Alle Dateien eines Ordners (rekursiv, inkl. versteckter), relativ
async function walkAll(dir, rel = '', out = [], dirs = []) {
  const ents = await fsp.readdir(path.join(dir, rel), { withFileTypes: true });
  for (const d of ents) {
    const r = path.join(rel, d.name);
    if (d.name === '.DS_Store') continue;
    if (d.isDirectory()) { dirs.push(r); await walkAll(dir, r, out, dirs); }
    else out.push(r);
  }
  return out;
}
// Kopiert src -> dest Datei für Datei, prüft danach Anzahl und Größen. Wirft bei Problemen.
async function copyVerified(src, dest, skip) {
  const dirs = [];
  const files = (await walkAll(src, '', [], dirs)).filter(r => !skip.includes(r));
  const ph = files.find(r => /(^|\/)\.[^/]+\.icloud$/.test(r));
  if (ph) throw new Error('Einige Dateien liegen noch nur in iCloud. Im Finder auf den Kunden-Ordner rechtsklicken → „Jetzt laden“, warten, dann nochmal versuchen.');
  for (const r of dirs) await fsp.mkdir(path.join(dest, r), { recursive: true });
  let done = 0, bytes = 0;
  for (const r of files) {
    const s = path.join(src, r), d = path.join(dest, r);
    await fsp.mkdir(path.dirname(d), { recursive: true });
    if (fs.existsSync(d)) throw new Error(`Am Ziel gibt es schon „${r}“. Abgebrochen, damit nichts überschrieben wird.`);
    await fsp.copyFile(s, d);
    bytes += (await fsp.stat(d)).size; done++;
    sendMove(`Kopiere ${done} von ${files.length} Dateien (${(bytes / 1e9).toFixed(2).replace('.', ',')} GB) …`);
  }
  sendMove('Prüfe die Kopie …');
  for (const r of dirs) if (!fs.existsSync(path.join(dest, r))) throw new Error(`Der Ordner „${r}“ fehlt in der Kopie. Nichts wurde gelöscht.`);
  for (const r of files) {
    const a = await fsp.stat(path.join(src, r)), b = await fsp.stat(path.join(dest, r)).catch(() => null);
    if (!b || a.size !== b.size) throw new Error(`Die Kopie von „${r}“ ist unvollständig. Nichts wurde gelöscht.`);
  }
  return files.length;
}
handle('moveClientOut', async cp => {
  const src = inRoot(cp);
  if (fs.existsSync(path.join(src, '_extern.json'))) throw new Error('Dieser Kunde liegt schon auf einer Festplatte.');
  const r = process.env.CLIPHAUS_TEST_DEST ? { canceled: false, filePaths: [process.env.CLIPHAUS_TEST_DEST] } : await dialog.showOpenDialog(win, { title: 'Auf welche Festplatte?', defaultPath: fs.existsSync('/Volumes') ? '/Volumes' : os.homedir(), properties: ['openDirectory', 'createDirectory'], buttonLabel: 'Hierhin verschieben' });
  if (r.canceled) return null;
  const base = r.filePaths[0];
  const dest = path.join(base, 'Cliphaus Kunden', path.basename(src));
  if (path.resolve(dest).startsWith(path.resolve(cfg.root) + path.sep)) throw new Error('Bitte einen Ort außerhalb des Team-Ordners wählen, z. B. deine Festplatte.');
  if (fs.existsSync(dest)) throw new Error(`Auf der Festplatte gibt es schon einen Ordner „${path.basename(src)}“ unter „Cliphaus Kunden“.`);
  sendMove('Lade Dateien aus iCloud, falls nötig …');
  await new Promise(res => execFile('/usr/bin/brctl', ['download', src], () => res()));
  let n;
  try { n = await copyVerified(src, dest, ['_kunde.json', '_extern.json']); }
  catch (e) { sendMove(''); await fsp.rm(dest, { recursive: true, force: true }).catch(() => {}); throw e; }
  // Kopie ist vollständig: Platzhalter schreiben, dann Inhalt in iCloud entfernen (außer _kunde.json)
  const volume = dest.startsWith('/Volumes/') ? dest.split('/')[2] : path.basename(base);
  await writeJson(path.join(src, '_extern.json'), { path: dest, volume, movedAt: new Date().toISOString() });
  sendMove('Räume iCloud auf …');
  for (const e of await fsp.readdir(src)) {
    if (e === '_kunde.json' || e === '_extern.json') continue;
    await fsp.rm(path.join(src, e), { recursive: true, force: true });
  }
  sendMove('');
  return { files: n, dest, volume };
});
handle('moveClientIn', async cp => {
  const stub = inRoot(cp);
  const ex = await readJson(path.join(stub, '_extern.json'), null);
  if (!ex || !ex.path) throw new Error('Dieser Kunde liegt nicht auf einer Festplatte.');
  if (!fs.existsSync(ex.path)) throw new Error(`Die Festplatte „${ex.volume || ''}“ ist nicht angeschlossen.`);
  let n;
  try { n = await copyVerified(ex.path, stub, ['_kunde.json', '_extern.json']); }
  catch (e) {
    sendMove('');
    // Halbe Kopie in iCloud wieder entfernen, der Platzhalter bleibt
    for (const f of await fsp.readdir(stub)) if (f !== '_kunde.json' && f !== '_extern.json') await fsp.rm(path.join(stub, f), { recursive: true, force: true }).catch(() => {});
    throw e;
  }
  await fsp.rm(path.join(stub, '_extern.json'), { force: true });
  sendMove('Räume die Festplatte auf …');
  await fsp.rm(ex.path, { recursive: true, force: true });
  sendMove('');
  return { files: n };
});
/* ---------- Updates über das GitHub-Repo cliphaus-updates ----------
   latest.json: { version, notes, kind: "app" | "full", file, electron }
   kind "app":  ZIP mit dem Ordner "app" (nur Cliphaus-Code, klein) -> ersetzt Contents/Resources/app
   kind "full": ZIP mit Cliphaus.app -> ersetzt die ganze App */
const UPDATE_BASE = process.env.CLIPHAUS_UPDATE_BASE || 'https://raw.githubusercontent.com/duncanmacaulay2-crypto/cliphaus-updates/main/';
const cmpVer = (a, b) => { const x = String(a).replace(/^v/, '').split('.').map(Number), y = String(b).replace(/^v/, '').split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
let latestRelease = null;
handle('updateCheck', async () => {
  const current = app.getVersion();
  try {
    const r = await fetch(UPDATE_BASE + 'latest.json?t=' + Date.now(), { headers: { 'User-Agent': 'Cliphaus' }, signal: AbortSignal.timeout(8000) });
    if (!r.ok) return { current, available: false };
    const j = await r.json();
    let kind = j.kind === 'full' ? 'full' : 'app';
    // Neue Electron-Version braucht das volle Paket
    if (kind === 'app' && j.electron && j.electron !== process.versions.electron) kind = j.full ? 'full' : 'manual';
    latestRelease = { version: String(j.version), kind, url: UPDATE_BASE + (kind === 'full' ? (j.full || j.file) : j.file), notes: j.notes || '' };
    const newer = cmpVer(latestRelease.version, current) > 0;
    return { current, latest: latestRelease.version, notes: latestRelease.notes, available: newer && kind !== 'manual', manual: newer && kind === 'manual' };
  } catch { return { current, available: false, offline: true }; }
});
handle('updateInstall', async () => {
  if (!latestRelease || latestRelease.kind === 'manual') throw new Error('Dieses Update muss einmal von Hand installiert werden.');
  const send = t => win && !win.isDestroyed() && win.webContents.send('update-progress', t);
  const work = await fsp.mkdtemp(path.join(os.tmpdir(), 'cliphaus-update-'));
  const zip = path.join(work, 'update.zip');
  send('Lade Update …');
  const r = await fetch(latestRelease.url + '?t=' + Date.now(), { headers: { 'User-Agent': 'Cliphaus' } });
  if (!r.ok) throw new Error('Download fehlgeschlagen (' + r.status + ').');
  const total = Number(r.headers.get('content-length')) || 0;
  const out = fs.createWriteStream(zip);
  let got = 0;
  for await (const chunk of r.body) {
    got += chunk.length; out.write(chunk);
    if (total) send(`Lade Update … ${Math.round(got / total * 100)} %`);
  }
  await new Promise(res => out.end(res));
  send('Entpacke …');
  const dir = path.join(work, 'x');
  await new Promise((res, rej) => execFile('/usr/bin/ditto', ['-x', '-k', zip, dir], err => err ? rej(new Error('Entpacken fehlgeschlagen.')) : res()));
  const payload = path.join(dir, latestRelease.kind === 'full' ? 'Cliphaus.app' : 'app');
  if (!fs.existsSync(payload)) throw new Error('Das Update-Paket ist unvollständig.');
  if (latestRelease.kind === 'app' && !fs.existsSync(path.join(payload, 'main.js'))) throw new Error('Das Update-Paket ist unvollständig.');
  const appPath = path.resolve(process.execPath, '..', '..', '..');
  if (!appPath.endsWith('.app')) throw new Error('Cliphaus läuft nicht aus einer installierten App. Bitte einmal normal installieren.');
  const script = path.join(work, 'install.sh');
  await fsp.writeFile(script, `#!/bin/bash
APP="$1"; NEW="$2"; PID="$3"; KIND="$4"
while kill -0 "$PID" 2>/dev/null; do sleep 0.5; done
if [ "$KIND" = "full" ]; then
  mv "$APP" "$HOME/.Trash/Cliphaus alt $(date +%s).app" || { open "$APP"; exit 1; }
  ditto "$NEW" "$APP"
else
  RES="$APP/Contents/Resources/app"
  mv "$RES" "$RES.alt" || { open "$APP"; exit 1; }
  if ! ditto "$NEW" "$RES"; then rm -rf "$RES"; mv "$RES.alt" "$RES"; open "$APP"; exit 1; fi
  rm -rf "$RES.alt"
fi
xattr -cr "$APP"
codesign --force --deep --sign - "$APP" 2>/dev/null
open "$APP"
`);
  send('Starte neu …');
  require('child_process').spawn('/bin/bash', [script, appPath, payload, String(process.pid), latestRelease.kind], { detached: true, stdio: 'ignore' }).unref();
  setTimeout(() => app.quit(), 300);
  return true;
});
handle('appVersion', async () => app.getVersion());
handle('free', async () => {
  try { const s = await fsp.statfs(cfg.root || os.homedir()); return s.bavail * s.bsize; } catch { return null; }
});
ipcMain.on('drag', (e, paths) => {
  try {
    const files = (Array.isArray(paths) ? paths : [paths]).map(inRoot);
    if (!files.length) return;
    e.sender.startDrag({ file: files[0], files, icon: dragIcon });
  } catch {}
});

/* ---------- Window ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 900, minHeight: 600, title: 'Cliphaus',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    backgroundColor: '#F1F2F7',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false }
  });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.loadFile(path.join(__dirname, 'index.html'));
  if (process.env.CLIPHAUS_SHOT) {
    win.webContents.on('did-finish-load', () => setTimeout(async () => {
      if (process.env.CLIPHAUS_JS) { try { await win.webContents.executeJavaScript(process.env.CLIPHAUS_JS); } catch (e) { console.error(e); } await new Promise(r => setTimeout(r, 1200)); }
      const img = await win.webContents.capturePage(); fs.writeFileSync(process.env.CLIPHAUS_SHOT, img.toPNG()); app.quit();
    }, 2500));
    win.webContents.on('console-message', (_e, _l, msg) => console.log('[renderer]', msg));
  }
}
app.whenReady().then(() => {
  cfgPath = path.join(app.getPath('userData'), 'config.json');
  loadCfg();
  dragIcon = nativeImage.createFromPath(path.join(__dirname, 'drag.png'));
  createWindow(); startWatch();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
