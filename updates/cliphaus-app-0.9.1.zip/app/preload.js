const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  invoke: async (ch, ...args) => {
    const r = await ipcRenderer.invoke(ch, ...args);
    if (!r.ok) throw new Error(r.error);
    return r.value;
  },
  drag: paths => ipcRenderer.send('drag', paths),
  onChange: fn => ipcRenderer.on('changed', () => fn()),
  onAiChunk: fn => ipcRenderer.on('ai-chunk', (_e, text) => fn(text)),
  onMoveProgress: fn => ipcRenderer.on('move-progress', (_e, text) => fn(text)),
  onUpdateProgress: fn => ipcRenderer.on('update-progress', (_e, text) => fn(text)),
  pathFor: file => webUtils.getPathForFile(file),
  fileUrl: p => 'file://' + p.split('/').map(encodeURIComponent).join('/')
});
