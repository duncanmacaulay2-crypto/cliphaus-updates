/* Cliphaus – Oberfläche */
(() => {
const api = window.api;
const STAGES = [
  ['idee', 'Idee', '--s1', 'Video ist angelegt, erst eine Idee'],
  ['skript', 'Skript', '--s2', 'Skript und Shotlist werden geschrieben'],
  ['dreh', 'Dreh', '--s3', 'Wird gedreht, Shots werden abgehakt'],
  ['schnitt', 'Schnitt', '--s4', 'Raw-Material ist da und wird geschnitten'],
  ['review', 'Review', '--s5', 'Export liegt vor und wartet auf Feedback'],
  ['frei', 'Freigegeben', '--s6', 'Abgenommen, bereit zum Posten'],
  ['gepostet', 'Gepostet', '--s7', 'Ist online']
];
const IX = Object.fromEntries(STAGES.map((s, i) => [s[0], i]));
const PLATS = [['instagram', 'Instagram', 2200], ['tiktok', 'TikTok', 2200]];
const S = {
  cfg: {}, teams: [], tree: null, icloud: false, icloudPath: '', free: null,
  view: 'over', sel: { c: null, p: null }, q: '', expanded: new Set(),
  open: null, tab: 'notiz', ver: null, showFiles: false, confirmDel: false, busy: '',
  dialog: null, playerKey: null, calMonth: null
};
try { JSON.parse(localStorage.getItem('exp') || '[]').forEach(x => S.expanded.add(x)); } catch {}
try { S.full = localStorage.getItem('drawerFull') === '1'; } catch {}
const saveExp = () => { try { localStorage.setItem('exp', JSON.stringify([...S.expanded])); } catch {} };

const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const todayStr = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const fmtDate = s => { if (!s) return ''; const [, m, d] = s.slice(0, 10).split('-'); return d + '.' + m + '.'; };
const fmtTC = t => { t = Math.max(0, t || 0); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(Math.floor(t % 60)).padStart(2, '0'); };
const fmtSize = b => !b ? '0 MB' : b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB';
const daysUntil = s => { if (!s) return null; return Math.round((new Date(s.slice(0, 10) + 'T00:00') - new Date(todayStr() + 'T00:00')) / 864e5); };

let toastT;
function toast(msg, err) {
  $('#toast-root').innerHTML = `<div class="toast ${err ? 'err' : ''}">${esc(msg)}</div>`;
  clearTimeout(toastT); toastT = setTimeout(() => { $('#toast-root').innerHTML = ''; }, err ? 5000 : 2200);
}
async function call(ch, ...a) {
  try { return await api.invoke(ch, ...a); } catch (e) { toast(e.message, true); throw e; }
}

/* ---------- Data ---------- */
function normalize(tree) {
  if (!tree) return;
  for (const c of tree.clients) for (const p of c.projects) for (const v of p.videos) {
    v.client = c; v.project = p;
    v.d = Object.assign({ title: v.folder, stage: 'idee', script: '', shots: [], captions: {}, platforms: { instagram: true, tiktok: true } }, v.data || {});
    v.d.captions = v.d.captions || {}; v.d.platforms = v.d.platforms || {};
    if (unsaved[v.path]) Object.assign(v.d, unsaved[v.path]);
    v.d.references = Array.isArray(v.d.references) ? v.d.references : []; v.d.notes = v.d.notes || '';
    v.d.scenes = Array.isArray(v.d.scenes) ? v.d.scenes : []; v.d.screenplay = v.d.screenplay || '';
    v.d.moodboard = Object.assign({ colors: [], notes: '' }, v.d.moodboard || {}); v.d.canva = v.d.canva || '';
    v.finals = v.finals || []; v.moodboard = v.moodboard || []; v.storyboard = v.storyboard || [];
  }
}
const clients = () => S.tree ? S.tree.clients : [];
const allVideos = () => clients().flatMap(c => c.projects.flatMap(p => p.videos));
const findVideo = p => allVideos().find(v => v.path === p);
const findClient = p => clients().find(c => c.path === p);
const findProject = p => clients().flatMap(c => c.projects).find(x => x.path === p);
const isRef = v => v.d.type === 'referenz';
const isKreativ = v => v.d.type === 'kreativ';
const typeIcon = v => isRef(v) ? '🔗 ' : isKreativ(v) ? '🎬 ' : '';
const SHOTS = ['Totale', 'Halbtotale', 'Halbnah', 'Nah', 'Close-up', 'Detail', 'Over-Shoulder', 'POV', 'Drohne', 'Kamerafahrt', 'Handheld'];
const activeTeam = () => S.teams.find(t => t.id === S.cfg.active) || {};
const onICloud = () => (activeTeam().location || 'icloud') === 'icloud';
const LOC_LABEL = { icloud: 'iCloud', mac: 'Dieser Mac', extern: 'Festplatte' };
const finalFile = v => (v.finals || []).slice(-1)[0] || v.exports.slice(-1)[0];
// Canva-Link in einen Einbettungs-Link umwandeln
function canvaEmbed(url) {
  const m = String(url || '').match(/canva\.com\/design\/([A-Za-z0-9_-]+)(?:\/([A-Za-z0-9_-]+))?/);
  if (!m) return null;
  const token = m[2] && !['edit', 'view', 'watch'].includes(m[2]) ? m[2] + '/' : '';
  return `https://www.canva.com/design/${m[1]}/${token}view?embed`;
}
const sceneSecs = v => (v.d.scenes || []).reduce((s, x) => s + (parseFloat(x.dauer) || 0), 0);
function platformOf(url) {
  const u = String(url || '').toLowerCase();
  if (u.includes('instagram.com')) return 'Instagram';
  if (u.includes('tiktok.com')) return 'TikTok';
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'YouTube';
  return 'Link';
}
const isDone = v => v.d.stage === 'frei' || v.d.stage === 'gepostet';
const knownNames = () => [...new Set([S.cfg.name, ...allVideos().flatMap(v => [v.d.assignee, v.d.createdBy, ...v.comments.map(c => c.by)])].filter(Boolean))];

function inSel(v) {
  if (S.sel.mine) return !!S.cfg.name && (v.d.assignee || '').trim().toLowerCase() === S.cfg.name.trim().toLowerCase();
  if (S.sel.p) return v.project.path === S.sel.p;
  if (S.sel.c) return v.client.path === S.sel.c;
  return true;
}
function matchQ(v) {
  if (!S.q) return true;
  return (v.d.title + ' ' + v.client.name + ' ' + v.project.name + ' ' + v.d.script).toLowerCase().includes(S.q.toLowerCase());
}
const listed = () => allVideos().filter(v => inSel(v) && matchQ(v)).sort((a, b) => (a.d.dueDate || '9999').localeCompare(b.d.dueDate || '9999'));
function nextDeadline(v) {
  const ix = IX[v.d.stage] ?? 0;
  if (ix <= 2 && v.d.shootDate) return ['Dreh', v.d.shootDate];
  if (ix <= 4 && v.d.dueDate) return ['Abgabe', v.d.dueDate];
  if (ix <= 5 && v.d.postAt) return ['Post', v.d.postAt];
  return null;
}
function dlChip(v) {
  const n = nextDeadline(v); if (!n) return '';
  const d = daysUntil(n[1]); const cls = d < 0 ? 'rec' : d <= 2 ? 'warn' : '';
  const rel = d < 0 ? `${-d} T. überfällig` : d === 0 ? 'heute' : d === 1 ? 'morgen' : fmtDate(n[1]);
  return `<span class="chip ${cls}">${n[0]} · ${rel}</span>`;
}
const rawStats = v => ({ n: v.raw.length, size: v.raw.reduce((s, f) => s + f.size, 0), local: v.raw.filter(f => f.local).length, localSize: v.raw.filter(f => f.local).reduce((s, f) => s + f.size, 0) });

const pending = {};
const unsaved = {}; // noch nicht geschriebene Änderungen je Video, damit ein Neu-Einlesen sie nicht überdeckt
function saveData(v, patch, delay) {
  Object.assign(v.d, patch);
  unsaved[v.path] = Object.assign(unsaved[v.path] || {}, patch);
  const run = () => {
    const sent = unsaved[v.path]; delete unsaved[v.path];
    const fresh = findVideo(v.path) || v;
    if (sent) Object.assign(fresh.d, sent);
    call('saveVideo', fresh.path, fresh.d).catch(() => {});
  };
  clearTimeout(pending[v.path]);
  if (delay) pending[v.path] = setTimeout(run, delay); else run();
}
// Automatische Stages: Raw da -> Schnitt, neuer Export -> Review
function autoStages() {
  for (const v of allVideos()) {
    const patch = {};
    const ix = IX[v.d.stage] ?? 0;
    if (v.raw.length && ix < IX.schnitt) patch.stage = 'schnitt';
    const n = v.exports.length;
    if (n > (v.d.seenExports || 0)) {
      patch.seenExports = n;
      if (v.d.stage !== 'gepostet') patch.stage = 'review';
      patch.approval = { state: 'pending', file: v.exports[n - 1].rel };
    }
    if (Object.keys(patch).length) saveData(v, patch);
  }
}

let refreshing = false, again = false;
async function refresh() {
  if (refreshing) { again = true; return; }
  refreshing = true;
  try {
    S.tree = await api.invoke('scan'); normalize(S.tree); autoStages();
    S.free = await api.invoke('free').catch(() => null);
    if (S.open && !findVideo(S.open)) S.open = null;
    if (S.sel.p && !findProject(S.sel.p)) S.sel.p = null;
    if (S.sel.c && !findClient(S.sel.c)) S.sel.c = null;
    renderShell(); renderSide(); renderMain();
    const ae = document.activeElement;
    const typing = ae && ae.closest && ae.closest('.drawer') && /^(TEXTAREA|INPUT)$/.test(ae.tagName) && ae.type !== 'checkbox';
    if (!typing) renderDrawer();
  } catch (e) { toast('Ordner konnte nicht gelesen werden: ' + e.message, true); }
  refreshing = false;
  if (again) { again = false; refresh(); }
}
let chT; api.onChange(() => { clearTimeout(chT); chT = setTimeout(refresh, 250); });
setInterval(refresh, 20000);
setInterval(async () => {
  try {
    const before = S.teams.length; const t = await api.invoke('teams');
    if (t.length !== before) { S.teams = t; renderSide(); if (t.length > before) toast('Neues Team gefunden: ' + t[t.length - 1].name); }
  } catch {}
}, 60000);

/* ---------- Shell ---------- */
function renderShell() {
  const root = $('#app');
  if (!S.cfg.root || !S.cfg.name) { if (!root.querySelector('.welcome')) root.innerHTML = welcomeHTML(); return; }
  if (root.querySelector('.shell')) {
    root.querySelectorAll('[data-view]').forEach(b => b.setAttribute('aria-pressed', b.dataset.view === S.view));
    return;
  }
  root.innerHTML = `<header class="top">
      <div class="brand"><span class="rec"></span>Cliphaus</div>
      <div class="tabs">${[['over', 'Übersicht'], ['board', 'Board'], ['cal', 'Kalender'], ['set', 'Einstellungen']].map(([k, l]) => `<button data-view="${k}" aria-pressed="${S.view === k}">${l}</button>`).join('')}</div>
      <div class="spacer"></div>
      <button id="upd-btn" class="btn small upd" data-act="update-install" hidden></button>
      <input id="q" class="search" type="search" placeholder="Videos suchen…" value="${esc(S.q)}">
      <button class="btn primary" data-act="new-video">+ Neues Video</button>
    </header>
    <div class="shell"><nav class="side" id="side"></nav><main class="main" id="main"></main></div>`;
}
function welcomeHTML() {
  const sugg = S.icloud ? S.icloudPath + '/Cliphaus' : '';
  return `<header class="top"><div class="brand"><span class="rec"></span>Cliphaus</div><div class="spacer"></div></header>
  <div class="welcome"><div class="inner">
    <h1>Willkommen bei Cliphaus</h1>
    <p class="sub">Alles läuft über einen Ordner in iCloud Drive, den du mit deinem Team teilst. Skripte, Raw-Material, Exporte und Kommentare liegen dort als ganz normale Dateien.</p>
    <div class="panel"><h2>1. Dein Name</h2><p>So sieht dein Team, wer kommentiert oder freigegeben hat.</p>
      <label class="f">Name<input id="w-name" value="${esc(S.cfg.name || '')}" placeholder="z. B. Duncan"></label></div>
    ${S.teams.length ? `<div class="panel"><h2>2. Deine Teams</h2><p>Diese Teams wurden in deinem iCloud Drive gefunden und werden automatisch verwendet:</p><p><b>${S.teams.map(t => esc(t.name)).join(' · ')}</b></p><p>Fehlt ein Team? Dann nimm zuerst die Einladung zum geteilten Ordner an (Link in Nachricht oder Mail). Cliphaus findet es danach von selbst.</p></div>` : `<div class="panel"><h2>2. Dein erstes Team</h2>
      <p>Ein Team ist ein eigener Ordner in iCloud Drive, z. B. „Management“ (teilst du mit deinem Team) oder „Persönlich“ (nur für dich). Weitere Teams legst du später links oben an.</p>
      <label class="f">Name des Teams<input id="w-team" value="Management"></label>
      <div class="row"><button class="btn" data-act="w-choose">Ich wurde eingeladen: geteilten Ordner wählen…</button></div>
      <div class="pathrow"><code id="w-root">${esc(S.cfg.root || (S.icloud ? 'Wird neu in iCloud Drive angelegt' : 'Wird in deinem Benutzerordner angelegt (iCloud Drive ist aus)'))}</code></div>
      <p>Wurdest du in ein Team eingeladen? Nimm zuerst die Einladung an, dann starte Cliphaus neu. Das Team wird automatisch gefunden.</p>
    </div>`}
    <div class="row"><button class="btn primary" data-act="w-start">Los geht's</button></div>
  </div></div>`;
}

/* ---------- Sidebar ---------- */
function renderSide() {
  const side = $('#side'); if (!side) return;
  const all = allVideos();
  const free = S.free;
  const mine = all.filter(v => !!S.cfg.name && (v.d.assignee || '').trim().toLowerCase() === S.cfg.name.trim().toLowerCase() && !isDone(v)).length;
  side.innerHTML = `<label class="f" style="margin:0 8px 12px">Team<select id="team-sel">${S.teams.map(t => `<option value="${esc(t.id)}" ${t.id === S.cfg.active ? 'selected' : ''} ${t.available === false ? 'disabled' : ''}>${esc(t.name)}${t.location && t.location !== 'icloud' ? ' · ' + LOC_LABEL[t.location] : ''}${t.available === false ? ' (nicht angeschlossen)' : ''}</option>`).join('')}<option value="__add">+ Team hinzufügen…</option></select></label>
    <button class="folder" data-act="sel-mine" aria-current="${!!S.sel.mine}"><span class="ic cl"></span><span class="name">Meine Aufgaben</span><span class="n">${mine}</span></button>
    <h3 style="margin-top:12px">Kunden &amp; Projekte</h3>
    <button class="folder" data-act="sel-all" aria-current="${!S.sel.c && !S.sel.p && !S.sel.mine}"><span class="ic"></span><span class="name">Alle Kunden</span><span class="n">${all.length}</span></button>
    ${clients().map(c => {
      const open = S.expanded.has(c.path);
      const n = c.projects.reduce((s, p) => s + p.videos.length, 0);
      return `<div class="frow"><button class="caret" data-exp="${esc(c.path)}" aria-expanded="${open}" aria-label="Auf- oder zuklappen">▶</button>
        <button class="folder kunde ${c.external && !c.external.available ? 'off' : ''}" data-selc="${esc(c.path)}" aria-current="${S.sel.c === c.path && !S.sel.p}" ${c.external ? `title="Liegt auf Festplatte „${esc(c.external.volume)}“${c.external.available ? '' : ' (nicht angeschlossen)'}"` : ''}><span class="ic cl"></span><span class="name">${esc(c.name)}</span>${c.external ? '<span class="ext-tag">⛁</span>' : ''}<span class="n">${n}</span></button>
        <button class="fadd" data-newp="${esc(c.path)}" title="Projekt anlegen">+</button><button class="fmore" data-client="${esc(c.path)}" title="Kunden-Einstellungen">⋯</button></div>
        ${open ? `<div class="kids">${c.projects.map(p => `<div class="frow"><button class="folder" data-selp="${esc(p.path)}" aria-current="${S.sel.p === p.path}"><span class="ic"></span><span class="name">${esc(p.name)}</span><span class="n">${p.videos.length}</span></button><button class="fmore" data-renp="${esc(p.path)}" title="Umbenennen">⋯</button></div>`).join('')
          || `<span class="col-empty">Noch keine Projekte · <button class="linkbtn" data-newp="${esc(c.path)}">+ Projekt</button></span>`}</div>` : ''}`;
    }).join('')}
    <button class="add-client" data-act="new-client">+ Neuer Kunde</button>
    <div class="foot">
      ${free != null ? `<div class="disk"><span>Freier Speicher auf dem Mac: <b>${fmtSize(free)}</b></span></div>` : ''}
      <span>Ordner: <span class="mono" style="font-size:11px">${esc(S.cfg.root.replace(S.icloudPath, 'iCloud Drive'))}</span></span>
    </div>`;
}

/* ---------- Main ---------- */
function crumbsHTML() {
  if (!S.sel.c) return '';
  const c = findClient(S.sel.c), p = S.sel.p && findProject(S.sel.p);
  return `<nav class="crumbs"><button data-act="sel-all">Alle Kunden</button>›${p ? `<button data-selc="${esc(c.path)}">${esc(c.name)}</button>›<span>${esc(p.name)}</span>` : `<span>${esc(c.name)}</span>`}</nav>`;
}
function selName() { if (S.sel.mine) return 'Meine Aufgaben'; if (S.sel.p) return findProject(S.sel.p)?.name || ''; if (S.sel.c) return findClient(S.sel.c)?.name || ''; return 'Alle Kunden'; }
function renderMain() {
  const m = $('#main'); if (!m) return;
  if (S.view === 'set') { m.innerHTML = settingsHTML(); loadAiSettings(); checkUpdate(); return; }
  if (S.tree && S.tree.missing) {
    m.innerHTML = `<div class="empty"><h2>${S.tree.location === 'extern' ? 'Festplatte nicht angeschlossen' : 'Team-Ordner nicht gefunden'}</h2><p>${S.tree.location === 'extern' ? 'Schließ die Festplatte mit dem Team „' + esc(activeTeam().name || '') + '“ an. Cliphaus öffnet es dann automatisch.' : 'Der Ordner wurde verschoben oder gelöscht. Wähle links ein anderes Team.'}</p></div>`;
    return;
  }
  if (!clients().length) {
    m.innerHTML = `<div class="empty"><h2>Lege deinen ersten Kunden an</h2>
      <p>So ist alles sortiert: Kunde → Projekt (z. B. „November 2026“) → Videos. Jedes Video ist ein Ordner mit Skript, RAW und EXPORT.</p>
      <div class="row"><button class="btn primary" data-act="new-client">+ Ersten Kunden anlegen</button><button class="btn" data-view="set">Team einladen</button></div></div>`;
    return;
  }
  const list = listed();
  const overdue = list.filter(v => { const n = nextDeadline(v); return n && daysUntil(n[1]) < 0; }).length;
  const soon = list.filter(v => { const n = nextDeadline(v); if (!n) return false; const d = daysUntil(n[1]); return d >= 0 && d <= 2; }).length;
  const head = `${crumbsHTML()}<h1 class="h1">${esc(selName())}</h1><div class="summary">
    <span class="pill">${list.length} Videos</span>${overdue ? `<span class="pill rec">${overdue} überfällig</span>` : ''}${soon ? `<span class="pill warn">${soon} in 2 Tagen fällig</span>` : ''}
    <span class="pill">${list.filter(v => v.d.stage === 'review').length} im Review</span><span class="pill ok">${list.filter(v => v.d.stage === 'gepostet').length} gepostet</span></div>`;
  m.innerHTML = head + (S.view === 'over' ? overviewHTML() : S.view === 'board' ? boardHTML(list) : calHTML(list));
}
function stageBar(list) {
  return `<div class="stbar">${list.length ? STAGES.map(([k, l, c]) => { const n = list.filter(v => v.d.stage === k).length; return n ? `<i style="width:${n / list.length * 100}%;background:var(${c})" title="${l}: ${n}"></i>` : ''; }).join('') : ''}</div>`;
}
function overviewHTML() {
  let cs = clients(); if (S.sel.c) cs = cs.filter(c => c.path === S.sel.c);
  const html = cs.map(c => {
    let projs = c.projects; if (S.sel.p) projs = projs.filter(p => p.path === S.sel.p);
    if (S.sel.mine) { projs = projs.filter(p => p.videos.some(inSel)); if (!projs.length) return ''; }
    const cv = c.projects.flatMap(p => p.videos);
    const acc = [c.meta.instagram && 'IG ' + c.meta.instagram, c.meta.tiktok && 'TikTok ' + c.meta.tiktok].filter(Boolean).join(' · ');
    if (c.external && !c.external.available) return `<section class="ov-client"><div class="ov-h"><h2>${esc(c.name)}</h2><span class="chip rec">⛁ Festplatte „${esc(c.external.volume)}“ nicht angeschlossen</span><button class="linkbtn" data-client="${esc(c.path)}">Kunden-Einstellungen</button></div><div class="note">Dieser Kunde liegt auf deiner Festplatte. Schließ sie an, dann erscheinen seine Projekte hier automatisch.</div></section>`;
    return `<section class="ov-client"><div class="ov-h"><h2><button data-selc="${esc(c.path)}">${esc(c.name)}</button></h2>${c.external ? `<span class="chip">⛁ Festplatte „${esc(c.external.volume)}“</span>` : ''}
      <span class="pill">${c.projects.length} Projekte · ${cv.length} Videos</span>
      <span class="acct">${esc(acc || 'Noch keine Accounts hinterlegt')}</span>
      <button class="linkbtn" data-client="${esc(c.path)}">Kunden-Einstellungen</button></div>
      ${projs.length ? `<div class="ov-grid">${projs.map(p => {
        const vids = p.videos.filter(v => matchQ(v) && (!S.sel.mine || inSel(v))).sort((a, b) => (IX[a.d.stage] ?? 0) - (IX[b.d.stage] ?? 0));
        const doneLocal = p.videos.filter(isDone).reduce((s, v) => s + rawStats(v).localSize, 0);
        return `<div class="ov-proj"><div class="ov-ph"><button class="pn" data-selp="${esc(p.path)}" data-goto="board">${esc(p.name)}</button><span class="r">${p.videos.filter(isDone).length}/${p.videos.length} fertig</span></div>
          ${stageBar(p.videos)}
          <div class="ov-list">${vids.map(v => { const st = STAGES[IX[v.d.stage] ?? 0]; return `<button class="ov-v" data-open="${esc(v.path)}"><span class="dot" style="background:var(${st[2]})"></span><span class="vt">${typeIcon(v)}${esc(v.d.title)}</span><span class="sl">${st[1]}</span>${dlChip(v)}</button>`; }).join('') || '<span class="col-empty">Noch keine Videos</span>'}</div>
          <div class="ov-foot"><button class="linkbtn" data-newv="${esc(p.path)}">+ Video</button>${onICloud() && doneLocal > 0 ? `<button class="linkbtn" data-cleanup="${esc(p.path)}" title="Entfernt die RAW-Dateien fertiger Videos vom Mac. Sie bleiben in iCloud.">Speicher freigeben (${fmtSize(doneLocal)})</button>` : ''}</div></div>`;
      }).join('')}</div>` : `<div class="note">Noch kein Projekt. <button class="linkbtn" data-newp="${esc(c.path)}">+ Projekt anlegen, z. B. „November 2026“</button></div>`}</section>`;
  }).join('');
  if (S.sel.mine && !html) return `<div class="empty"><h2>Dir ist gerade nichts zugewiesen</h2><p>Öffne ein Video und klick bei „Zuständig“ auf „Ich übernehme das“. Dann taucht es hier auf.</p></div>`;
  return `<div class="ov">${html}</div>`;
}
function cardHTML(v) {
  const shots = v.d.shots || []; const done = shots.filter(s => s.done).length; const r = rawStats(v);
  return `<button class="card" data-open="${esc(v.path)}" draggable="true" data-card="${esc(v.path)}">
    <div><div class="t">${isRef(v) ? '<span class="chip acc" style="margin-right:6px">Referenz</span>' : isKreativ(v) ? '<span class="chip warn" style="margin-right:6px">Kreativ</span>' : ''}${esc(v.d.title)}</div><div class="camp">${esc(v.client.name + ' › ' + v.project.name)}</div></div>
    ${shots.length ? `<div class="meta">${done}/${shots.length} Shots</div><div class="prog"><i style="width:${done / shots.length * 100}%"></i></div>` : ''}
    <div class="meta">${dlChip(v)}${r.n ? `<span class="chip">${r.n} Raw · ${fmtSize(r.size)}</span>` : ''}${v.exports.length ? `<span class="chip acc">v${v.exports.length}</span>` : ''}${v.d.approval?.state === 'changes' ? '<span class="chip rec">Änderungen</span>' : ''}</div>
    ${v.d.assignee ? `<div class="meta">${esc(v.d.assignee)}</div>` : ''}</button>`;
}
function boardHTML(list) {
  return `<div class="board-wrap"><div class="board">${STAGES.map(([k, l, c, tip]) => {
    const items = list.filter(v => v.d.stage === k);
    return `<section class="col" data-col="${k}"><div class="col-h" title="${esc(tip)}"><span class="dot" style="background:var(${c})"></span>${l}<span class="n">${items.length}</span></div>${items.map(cardHTML).join('') || '<div class="col-empty">Nichts hier</div>'}</section>`;
  }).join('')}</div></div>`;
}
function calHTML(list) {
  const base = S.calMonth || todayStr().slice(0, 7); const [y, mo] = base.split('-').map(Number);
  const first = new Date(y, mo - 1, 1); const start = new Date(first); start.setDate(1 - ((first.getDay() + 6) % 7));
  const evs = {}; const add = (d, type, label, v) => { if (!d) return; (evs[d.slice(0, 10)] = evs[d.slice(0, 10)] || []).push({ type, label, v }); };
  for (const v of list) { add(v.d.shootDate, 'dreh', 'Dreh', v); add(v.d.dueDate, 'abgabe', 'Abgabe', v); add(v.d.postAt, 'post', 'Post', v); }
  let cells = ''; const t = todayStr();
  for (let i = 0; i < 42; i++) {
    const d = new Date(start); d.setDate(start.getDate() + i);
    const k = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    cells += `<div class="day ${d.getMonth() !== mo - 1 ? 'out' : ''} ${k === t ? 'today' : ''}"><span class="dn">${d.getDate()}</span>${(evs[k] || []).map(e => `<button class="ev ${e.type}" data-open="${esc(e.v.path)}" title="${esc(e.label + ': ' + e.v.d.title)}"><b>${e.label}</b>${esc(e.v.d.title)}</button>`).join('')}</div>`;
    if (i === 34 && d.getMonth() !== mo - 1) break;
  }
  return `<div class="cal-head"><button class="btn small" data-cal="-1">‹</button><strong style="font-size:16px;min-width:150px;text-align:center">${first.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</strong><button class="btn small" data-cal="1">›</button><button class="btn small" data-cal="0">Heute</button>
    <div class="legend"><span class="chip warn">Dreh</span><span class="chip rec">Abgabe</span><span class="chip acc">Posting</span></div></div>
    <div class="cal">${['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(d => `<div class="dow">${d}</div>`).join('')}${cells}</div>`;
}
function settingsHTML() {
  const root = S.cfg.root || '';
  return `<h1 class="h1">Einstellungen</h1>
  <div class="panel"><h2>Dein Name</h2><div class="row"><input id="s-name" class="search" style="width:260px" value="${esc(S.cfg.name || '')}"><button class="btn small" data-act="s-name">Speichern</button></div></div>
  <div class="panel"><h2>Teams</h2>
    <p>Jedes Team ist ein eigener Ordner in iCloud Drive. Geteilte Ordner sehen alle Eingeladenen, ungeteilte nur du.</p>
    ${S.teams.map(t => `<div class="pathrow"><b style="min-width:120px">${esc(t.name)}${t.id === S.cfg.active ? ' ✓' : ''}</b><span class="chip ${t.available === false ? 'rec' : ''}">${t.available === false ? 'nicht angeschlossen' : LOC_LABEL[t.location] || 'iCloud'}</span><code>${esc(t.root.replace(S.icloudPath, 'iCloud Drive'))}</code><button class="btn small" data-renteam="${esc(t.id)}">Umbenennen</button><button class="btn small" data-reveal-team="${esc(t.root)}">Im Finder</button><button class="btn small" data-rmteam="${esc(t.id)}">Entfernen</button></div>`).join('')}
    <div class="row"><button class="btn small primary" data-act="add-team">+ Team hinzufügen</button></div></div>
  <div class="panel"><h2>Aktueller Team-Ordner</h2><div class="pathrow"><code>${esc(root)}</code><button class="btn small" data-reveal="${esc(root)}">Im Finder zeigen</button><button class="btn small" data-act="s-root">Ändern</button></div>
    <p>Alles liegt hier: <span class="mono">Kunde / Projekt / Video / RAW</span> und <span class="mono">EXPORT</span>. iCloud lädt neue Dateien im Hintergrund hoch und auf die Macs deines Teams herunter.</p></div>
  <div class="panel"><h2>Team einladen (z. B. Management)</h2><ol>
    <li>Im Finder auf den Ordner des Teams rechtsklicken (siehe „Im Finder“ oben) → <b>Teilen</b> → <b>Ordner teilen…</b></li>
    <li>Die drei Personen per E-Mail oder Telefonnummer ihrer Apple-ID einladen. Berechtigung: <b>„Kann Änderungen vornehmen“</b>. Der Speicher zählt nur auf deine iCloud.</li>
    <li>Jede Person nimmt die Einladung an, installiert Cliphaus und wählt beim ersten Start <b>„Geteilten Ordner wählen“</b> → den geteilten Team-Ordner in iCloud Drive. Auf dem iPhone: ••• → „Team hinzufügen“.</li>
    <li>Für ein <b>persönliches</b> Team den Ordner einfach nicht teilen.</li></ol></div>
  <div class="panel"><h2>Auf dem iPhone</h2>
    <p>Cliphaus legt automatisch die Datei <b>„Cliphaus Übersicht.html“</b> in den Cliphaus-Ordner. Sie zeigt alle Kunden, Projekte und Videos mit Stage, Deadline, Raw-Stand und Captions.</p><ol>
    <li><b>Übersicht ansehen:</b> iPhone → App <b>Dateien</b> → iCloud Drive → Cliphaus → „Cliphaus Übersicht“ antippen. Tipp: lange drücken → <b>Favoriten</b>, dann ist sie mit einem Tipp da.</li>
    <li><b>Raw hochladen:</b> In <b>Fotos</b> die Clips auswählen → Teilen → <b>„In Dateien sichern“</b> → Cliphaus › Kunde › Projekt › Video › <b>RAW</b> → Sichern. iCloud lädt im Hintergrund hoch, Cliphaus auf dem Mac zeigt die Clips automatisch an und stellt das Video auf „Schnitt“.</li>
    <li><b>Wichtig fürs Hochladen:</b> iPhone-Einstellungen → Apple-ID → iCloud → iCloud Drive → <b>„Mobile Daten verwenden“</b> nur einschalten, wenn genug Datenvolumen da ist. Im WLAN geht es am schnellsten.</li>
    <li><b>Posten vom Handy:</b> In der <b>Metricool-App</b> einen Post anlegen und das Video über <b>„Dateien“</b> aus dem EXPORT-Ordner wählen. Die Caption steht in der Übersicht zum Kopieren.</li></ol></div>
  <div class="panel"><h2>Updates</h2><p id="ver-line">Version …</p>
    <div class="row"><button class="btn small" data-act="update-check">Nach Updates suchen</button>${UPD && UPD.available ? `<button class="btn small primary" data-act="update-install">Update ${esc(UPD.latest)} installieren</button>` : ''}</div>
    <p>Cliphaus sucht beim Start selbst nach Updates. Ist eins da, erscheint oben der Knopf „Update installieren“. Ein Klick, und Cliphaus aktualisiert sich und startet neu.</p></div>
  <div class="panel"><h2>Lokale KI (Drehbuch aus Shots)</h2>
    <div id="ai-settings"><p class="sub">Prüfe …</p></div>
    <ol>
      <li><b>Ollama</b> kostenlos laden: <button class="linkbtn" data-url="https://ollama.com/download">ollama.com/download</button> → ZIP öffnen → <b>Ollama</b> in „Programme“ ziehen → öffnen.</li>
      <li><b>Terminal</b> öffnen und eingeben: <code>ollama pull gemma3:12b</code> → Enter. Einmalig ca. 8 GB.</li>
      <li>Fertig. Im Kreativ-Video unter den Shots: <b>„✨ Drehbuch aus Shots erstellen“</b>.</li>
    </ol>
    <p>Die KI läuft komplett auf deinem Mac, kostet nichts und braucht kein Internet. Ollama muss dafür geöffnet sein (Lama-Symbol oben in der Menüleiste).</p></div>
  <div class="panel"><h2>Speicher sparen</h2><ol>
    <li>In den Systemeinstellungen → Apple-ID → iCloud → <b>„Mac-Speicher optimieren“ ausschalten</b>, damit macOS nicht selbst Dateien mitten im Schnitt entfernt.</li>
    <li>Im Video vor dem Schneiden <b>„Auf den Mac laden“</b>, danach <b>„Vom Mac entfernen“</b>. In der Übersicht gibt es pro Projekt <b>„Speicher freigeben“</b> für fertige Videos.</li>
    <li>CapCut: In den Einstellungen regelmäßig den <b>Cache leeren</b>.</li></ol></div>
  <div class="panel"><h2>Posten auf Instagram und TikTok</h2><p>Lege in Metricool pro Kunde eine Marke an und verbinde dort dessen Instagram- und TikTok-Account. Den Link zur Marke trägst du in den Kunden-Einstellungen ein (⋯ neben dem Kunden). Im Video unter „Posting“ kopierst du dann Caption und Datei mit einem Klick.</p></div>`;
}

/* ---------- Drawer ---------- */
function renderDrawer(full) {
  const root = $('#drawer-root'); const v = S.open && findVideo(S.open);
  if (!v) { root.innerHTML = ''; S.playerKey = null; return; }
  const ae = document.activeElement; const keep = ae && ae.id && root.contains(ae) ? { id: ae.id, val: ae.value, s: ae.selectionStart, e: ae.selectionEnd } : null;
  if (!root.firstChild || full) {
    root.innerHTML = `<div class="scrim" data-act="close"></div><aside class="drawer ${S.full ? 'full' : ''}"><div class="dr-head" id="dr-head"></div><div class="dr-body" id="dr-body"></div></aside>`;
    S.playerKey = null;
  }
  $('#dr-head').innerHTML = headHTML(v);
  const body = $('#dr-body');
  if (S.tab === 'review') renderReview(v, body); else { S.playerKey = null; body.innerHTML = S.tab === 'posting' ? postingHTML(v) : notizHTML(v); }
  autoDownloadImages(v);
  if (keep) { const el = document.getElementById(keep.id); if (el) { if (el.type !== 'checkbox' && keep.val !== undefined) el.value = keep.val; el.focus(); try { el.setSelectionRange(keep.s, keep.e); } catch {} } }
}
function headHTML(v) {
  const tabs = [['notiz', 'Notiz & Material', ''], ['review', 'Review', v.exports.length], ['posting', 'Posting', '']];
  return `<div class="crumbs">${esc(v.client.name)} › ${esc(v.project.name)}</div>
    <div class="dr-row"><input id="f-title" class="title-in" value="${esc(v.d.title)}" aria-label="Titel"><button class="btn small dr-size" data-act="toggle-full" title="${S.full ? 'Zurück zur Seitenansicht' : 'Auf ganze Breite öffnen'} (⌘⇧F)">${S.full ? '⤡ Seitenansicht' : '⤢ Vollbild'}</button><button class="x" data-act="close" aria-label="Schließen">×</button></div>
    <div class="row" style="gap:6px"><span class="sub" style="margin:0;font-size:12px">Art:</span>${[['skript', 'Skript-Video'], ['referenz', 'Referenz-Video'], ['kreativ', 'Kreativ-Video']].map(([k, l]) => `<button class="stage" data-vtype="${k}" aria-pressed="${(v.d.type || 'skript') === k}">${l}</button>`).join('')}</div>
    <div class="stages">${STAGES.map(([k, l, c, tip]) => `<button class="stage" data-stage="${k}" title="${esc(tip)}" aria-pressed="${v.d.stage === k}"><span class="dot" style="background:var(${c})"></span>${l}</button>`).join('')}</div>
    <div class="dtabs">${tabs.map(([k, l, c]) => `<button data-tab="${k}" aria-selected="${S.tab === k}">${l}<span class="c">${c || ''}</span></button>`).join('')}</div>`;
}
function kreativHTML(v) {
  const mb = v.d.moodboard; const scenes = v.d.scenes;
  const secs = sceneSecs(v);
  // Bild eines Shots: per gespeichertem Namen, sonst über die Shot-ID im Dateinamen
  const sbFor = sc => (sc.img && v.storyboard.find(f => f.rel === sc.img)) || (sc.id && v.storyboard.filter(f => f.rel.startsWith(sc.id + '-')).sort((a, b) => b.mtime - a.mtime)[0]) || null;
  const used = new Set(scenes.map(sc => sbFor(sc)).filter(Boolean).map(f => f.rel));
  const orphans = v.storyboard.filter(f => !used.has(f.rel));
  return `<div class="kreativ">
    <div class="sec-h">Drehbuch</div>
    <textarea id="f-screenplay" class="script screenplay" placeholder="SZENE 1 – INNEN – CAFÉ – MORGEN&#10;&#10;Erstes Licht fällt durch das Fenster. Lena stellt die Siebträger-Maschine an.&#10;&#10;LENA (leise)&#10;Jeder Tag beginnt mit dem ersten Shot.">${esc(v.d.screenplay)}</textarea>

    <div class="sec-h">Shots<span class="r">${scenes.length} Shots · ${secs ? Math.floor(secs / 60) + ':' + String(Math.round(secs % 60)).padStart(2, '0') + ' min' : 'Dauer offen'}</span></div>
    <div class="scenes">${scenes.map((sc, i) => { const f = sbFor(sc); const has = f && f.local; const cloud = f && !f.local; const missing = !f && sc.img; return `<div class="scene" data-scenedrop="${i}">
        <div class="sc-left">
          ${has ? `<button class="sc-img" data-viewimg="${esc(f.path)}" title="Groß ansehen"><img src="${esc(api.fileUrl(f.path))}?t=${Math.round(f.mtime)}" alt=""></button>`
                : cloud ? `<button class="sc-img" data-dlfile="${esc(f.path)}" title="Bild wird aus iCloud geladen"><span>☁︎ Lädt aus iCloud …</span></button>`
                : missing ? `<button class="sc-img missing" data-sceneimg="${i}" title="Die Bilddatei fehlt. Klicken, um ein Bild einzusetzen."><span>⚠︎ Bild fehlt<br><small>klicken zum Einsetzen</small></span></button>`
                : `<button class="sc-img" data-sceneimg="${i}" title="Bild wählen oder hierher ziehen"><span>+ Bild</span></button>`}
          ${has || cloud ? `<button class="linkbtn" data-sceneimg="${i}">Bild ändern</button>` : ''}
          ${missing && orphans.length ? `<span class="sub" style="font-size:11.5px">Tipp: unten bei „Bilder ohne Shot“ nachsehen</span>` : ''}
        </div>
        <div class="sc-body">
          <div class="sc-top"><b class="mono">Shot ${String(i + 1).padStart(2, '0')}</b>
            <input id="sc-${i}-title" data-sc="${i}" data-scf="title" value="${esc(sc.title || '')}" placeholder="Titel, z. B. Erstes Licht">
            <button class="del" data-scmove="${i}:-1" title="Nach oben">↑</button><button class="del" data-scmove="${i}:1" title="Nach unten">↓</button><button class="del" data-scdel="${i}" title="Shot löschen">×</button></div>
          <div class="sc-fields">
            <label>Einstellung<select id="sc-${i}-shot" data-sc="${i}" data-scf="shot"><option value="">–</option>${SHOTS.map(o => `<option ${sc.shot === o ? 'selected' : ''}>${o}</option>`).join('')}</select></label>
            <label>Brennweite<span class="unit"><input id="sc-${i}-brennweite" list="focal" data-sc="${i}" data-scf="brennweite" value="${esc(sc.brennweite || '')}" placeholder="35">mm</span></label>
            <label>Dauer<span class="unit"><input id="sc-${i}-dauer" type="number" min="0" step="0.5" data-sc="${i}" data-scf="dauer" value="${esc(sc.dauer || '')}" placeholder="3">s</span></label>
            <label class="wide">Ort / Set<input id="sc-${i}-ort" data-sc="${i}" data-scf="ort" value="${esc(sc.ort || '')}" placeholder="z. B. Café-Theke, Morgenlicht"></label>
          </div>
          <textarea id="sc-${i}-text" data-sc="${i}" data-scf="text" placeholder="Was passiert? Kamera, Licht, Bewegung">${esc(sc.text || '')}</textarea>
          <textarea id="sc-${i}-ton" data-sc="${i}" data-scf="ton" placeholder="Dialog, Voice-over, Musik, Sound">${esc(sc.ton || '')}</textarea>
        </div></div>`; }).join('')}</div>
    ${orphans.length ? `<div class="orphans"><div class="sec-h" style="margin:14px 0 6px">Bilder ohne Shot<span class="r">${orphans.length} gefunden</span></div>
      <p class="sub" style="margin:0 0 8px;font-size:12.5px">Diese Bilder liegen im Video-Ordner, gehören aber zu keinem Shot (z. B. nach einem Sync-Fehler). Wähle, zu welchem Shot sie gehören.</p>
      <div class="orph-grid">${orphans.map(f => `<div class="orph">${f.local ? `<button class="sc-img" data-viewimg="${esc(f.path)}"><img src="${esc(api.fileUrl(f.path))}?t=${Math.round(f.mtime)}" alt=""></button>` : `<button class="sc-img" data-dlfile="${esc(f.path)}"><span>☁︎ Laden</span></button>`}
        <select data-orphan="${esc(f.rel)}"><option value="">Zu Shot …</option>${scenes.map((sc, i) => `<option value="${i}">Shot ${String(i + 1).padStart(2, '0')}${sc.title ? ' · ' + esc(sc.title) : ''}</option>`).join('')}</select></div>`).join('')}</div></div>` : ''}
    <datalist id="focal">${[14, 16, 24, 28, 35, 50, 85, 100, 135, 200].map(n => `<option value="${n}">`).join('')}</datalist>
    <div class="row" style="margin-top:10px"><button class="btn small primary" data-act="sc-add">+ Shot</button>
      <button class="btn small ai-btn" data-act="ai-open" ${scenes.length ? '' : 'disabled title="Erst Shots anlegen"'}>✨ Drehbuch aus Shots erstellen</button></div>

    <div class="sec-h">Moodboard<span class="r">${v.moodboard.length} Bilder · ${mb.colors.length} Farben</span></div>
    <div class="mood" data-droptarget="MOODBOARD">
      <div class="mood-grid">${v.moodboard.map(f => `<div class="mood-img">${f.local ? `<button class="mood-open" data-viewimg="${esc(f.path)}" title="Groß ansehen"><img src="${esc(api.fileUrl(f.path))}?t=${Math.round(f.mtime)}" alt=""></button>` : '<span class="sub">in iCloud</span>'}<button class="mood-x" data-rmfile="${esc(f.path)}" aria-label="Bild entfernen">×</button></div>`).join('')}
        <button class="mood-add" data-act="mood-pick"><span>+</span>Bilder hinzufügen<small>oder hierher ziehen</small></button></div>
      <div class="palette">${mb.colors.map((c, i) => `<span class="swatch" style="background:${esc(c)}" title="${esc(c)}"><button data-rmcolor="${i}" aria-label="Farbe entfernen">×</button><small>${esc(c)}</small></span>`).join('')}
        <label class="swatch add" title="Farbe hinzufügen"><input type="color" id="mb-color" value="#c27a12">+</label></div>
      <textarea id="mb-notes" class="mood-notes" placeholder="Stimmung, Licht, Look, Musik … z. B. warmes Morgenlicht, langsame Kamerafahrten, Film-Korn, ruhiger Piano-Track">${esc(mb.notes)}</textarea>
    </div>

    <div class="sec-h">Canva-Link</div>
    <div class="pathrow"><input id="canva-link" class="canva-in" value="${esc(v.d.canva)}" placeholder="Link zu deinem Canva-Design (optional)">${v.d.canva ? `<button class="btn small" data-url="${esc(v.d.canva.replace(/\?embed$/, ''))}">In Canva öffnen</button>` : ''}</div>
  </div>`;
}
function refsHTML(v) {
  const refs = v.d.references;
  return `<div class="sec-h">Referenzen<span class="r">${refs.length} Link${refs.length === 1 ? '' : 's'}</span></div>
    <div class="refs">${refs.map((r, i) => `<div class="ref">
        <div class="ref-h"><span class="chip acc">${platformOf(r.url)}</span><span class="ref-url" title="${esc(r.url)}">${esc(r.url)}</span>
          <button class="btn small" data-url="${esc(r.url)}">Öffnen</button><button class="btn small" data-copy="${esc(r.url)}">Kopieren</button><button class="del" data-delref="${i}" aria-label="Referenz entfernen">×</button></div>
        <textarea id="ref-note-${i}" data-refnote="${i}" placeholder="Was gefällt dir daran? z. B. Schnitt-Rhythmus, Hook, Musik, Text-Einblendung">${esc(r.note || '')}</textarea></div>`).join('')}
      <form class="ref-add" id="ref-form"><input id="ref-new" placeholder="Instagram-, TikTok- oder YouTube-Link einfügen (⌘V)"><button class="btn small primary">Hinzufügen</button></form></div>
    <div class="sec-h">Notizen zur Umsetzung</div>
    <textarea id="f-notes" class="script" style="min-height:140px" placeholder="Wie setzen wir das um? Wer spielt mit, wo drehen wir, was machen wir anders als das Original?">${esc(v.d.notes)}</textarea>`;
}
function notizHTML(v) {
  const shots = v.d.shots || []; const done = shots.filter(s => s.done).length; const r = rawStats(v);
  const rawDir = v.path + '/RAW', expDir = v.path + '/EXPORT';
  return `<div class="grid3">
      <label class="f">Drehtag<input id="f-shoot" type="date" value="${esc(v.d.shootDate || '')}"></label>
      <label class="f">Abgabe Schnitt<input id="f-due" type="date" value="${esc(v.d.dueDate || '')}"></label>
      <label class="f">Zuständig<input id="f-assignee" list="names" value="${esc(v.d.assignee || '')}" placeholder="Name">${S.cfg.name && v.d.assignee !== S.cfg.name ? `<button type="button" class="linkbtn" data-act="assign-me" style="text-align:left;text-transform:none;letter-spacing:0">Ich übernehme das</button>` : ''}</label>
    </div><datalist id="names">${knownNames().map(n => `<option value="${esc(n)}">`).join('')}</datalist>
    ${isRef(v) ? refsHTML(v) : ''}
    ${isKreativ(v) ? kreativHTML(v) : ''}
    ${(!isRef(v) && !isKreativ(v)) || v.d.script ? `<div class="sec-h">Skript${isRef(v) || isKreativ(v) ? ' (optional)' : ''}</div>
    <textarea id="f-script" class="script" placeholder="HOOK (0–3 s): …&#10;&#10;HAUPTTEIL: …&#10;&#10;CALL TO ACTION: …">${esc(v.d.script || '')}</textarea>` : ''}
    <div class="sec-h">Shotlist<span class="r">${done}/${shots.length} abgefilmt</span></div>
    <div class="shots">${shots.map((s, i) => `<div class="shot ${s.done ? 'done' : ''}"><span class="num">${String(i + 1).padStart(2, '0')}</span><input type="checkbox" data-shot="${i}" ${s.done ? 'checked' : ''}><span class="tx">${esc(s.text)}</span><button class="del" data-delshot="${i}" aria-label="Shot löschen">×</button></div>`).join('')}
      <form class="shot-add" id="shot-form"><input id="shot-new" placeholder="Neuer Shot, z. B. Close-up Produkt"><button class="btn small">Hinzufügen</button></form></div>

    <div class="sec-h">Raw-Material</div>
    <div class="fcard" data-droptarget="RAW">
      <div class="fchip" draggable="true" data-drag="${esc(rawDir)}" title="In CapCut oder DaVinci in die Timeline ziehen">
        <span class="big"></span><div><b>RAW · ${esc(v.d.title)}</b><small>${r.n ? `${r.n} Dateien · ${fmtSize(r.size)} · ${r.local === r.n ? 'alles auf dem Mac' : `${r.local} von ${r.n} auf dem Mac`}` : 'Noch leer'}</small></div>
        <span class="drag">Ordner in die<br>Timeline ziehen</span></div>
      ${S.busy ? `<div class="busy">${esc(S.busy)}</div>` : ''}
      <div class="row">
        ${onICloud() && r.n && r.local < r.n ? `<button class="btn small primary" data-dl="${esc(v.path)}">Auf den Mac laden</button>` : ''}
        ${onICloud() && r.local ? `<button class="btn small" data-evict="${esc(v.path)}">Vom Mac entfernen (${fmtSize(r.localSize)})</button>` : ''}
        <button class="btn small" data-reveal="${esc(rawDir)}">Im Finder zeigen</button>
        ${r.n ? `<button class="btn small" data-act="files">${S.showFiles ? 'Dateien ausblenden' : 'Einzelne Dateien'}</button>` : ''}
      </div>
      ${S.showFiles && r.n ? `<div class="flist">${v.raw.map(f => `<div class="fl" draggable="true" data-drag="${esc(f.path)}"><span class="cloud ${f.local ? 'l' : 'c'}">${f.local ? 'Mac' : 'iCloud'}</span><span class="nm">${esc(f.rel)}</span><span class="sz">${fmtSize(f.size)}</span></div>`).join('')}</div>` : ''}
      <div class="note">${r.n ? '' : '<b>Dein Partner</b> zieht seinen Raw-Ordner einfach hier hinein (oder im Finder in den RAW-Ordner). '}iCloud lädt im Hintergrund hoch, auf den anderen Macs erscheinen die Dateien automatisch. Neue Dateien kannst du jederzeit hier hineinziehen.</div>
    </div>

    <div class="sec-h">Export</div>
    <div class="fcard">
      <div class="fchip" draggable="true" data-drag="${esc(expDir)}"><span class="big exp"></span><div><b>EXPORT · ${esc(v.d.title)}</b><small>${v.exports.length ? `${v.exports.length} Version${v.exports.length > 1 ? 'en' : ''}` : 'Noch kein Export'}</small></div></div>
      <div class="pathrow"><code id="p-exp">${esc(expDir)}</code><button class="btn small" data-copy="${esc(expDir)}">Pfad kopieren</button><button class="btn small" data-reveal="${esc(expDir)}">Im Finder</button></div>
      <div class="note"><b>Direkt in Cliphaus exportieren:</b> In CapCut beim Export unter „Speichern unter“ diesen Ordner wählen (im Dialog <b>⌘ ⇧ G</b> drücken und den kopierten Pfad einfügen). Jeder Export erscheint automatisch als neue Version im Review, das Video springt auf „Review“.</div>
    </div>

    <div class="sec-h" style="margin-top:30px">Video verwalten</div>
    ${S.confirmDel ? `<div class="confirm">Ordner mit Skript, RAW und Exporten in den Papierkorb legen? Das betrifft das ganze Team.<button class="btn small danger" data-act="del-yes">Ja, löschen</button><button class="btn small" data-act="del-no">Abbrechen</button></div>`
      : `<div class="row"><button class="btn small" data-reveal="${esc(v.path)}">Video-Ordner im Finder</button><button class="btn small danger" data-act="del">In den Papierkorb</button></div>`}`;
}
function currentVersion(v) {
  const vs = v.exports; if (!vs.length) return null;
  return vs.find(x => x.rel === S.ver) || vs[vs.length - 1];
}
function renderReview(v, body) {
  const cur = currentVersion(v);
  const key = v.path + ':' + (cur ? cur.rel + cur.local : 'none');
  if (S.playerKey !== key) {
    if (!cur) {
      body.innerHTML = `<div class="note"><b>Noch kein Export.</b> Exportiere in CapCut oder DaVinci direkt in den EXPORT-Ordner dieses Videos (Pfad unter „Notiz &amp; Material“). Die Datei erscheint dann automatisch hier, und dein Team kann mit Timecode kommentieren.</div>`;
    } else {
      body.innerHTML = `<div class="vbar" id="rv-vbar"></div>
        ${cur.local ? `<div class="player"><video id="player" src="${esc(api.fileUrl(cur.path))}" controls preload="metadata"></video></div>
        <div class="timeline"><span class="ph" id="ph" style="left:0"></span><div id="mks"></div></div>`
        : `<div class="note" style="margin-top:10px"><b>Diese Version liegt noch nur in iCloud.</b> <button class="btn small primary" data-dlfile="${esc(cur.path)}">Auf den Mac laden</button></div>`}
        <div id="rv-side" style="display:flex;flex-direction:column;gap:12px;margin-top:14px"></div>`;
      const p = $('#player');
      if (p) {
        p.addEventListener('timeupdate', () => { const d = p.duration || 0; $('#ph').style.left = (d ? p.currentTime / d * 100 : 0) + '%'; const tc = $('#tc'); if (tc) tc.textContent = fmtTC(p.currentTime); });
        p.addEventListener('loadedmetadata', () => renderReviewSide(v));
      }
    }
    S.playerKey = key;
  }
  if (cur) renderReviewSide(v);
}
function renderReviewSide(v) {
  const side = $('#rv-side'); if (!side) return; const cur = currentVersion(v); if (!cur) return;
  $('#rv-vbar').innerHTML = `<span class="sub" style="margin:0 6px 0 0">Version</span>${v.exports.map((x, i) => `<button class="ver" data-ver="${esc(x.rel)}" aria-pressed="${x.rel === cur.rel}" title="${esc(x.rel)}">v${i + 1}</button>`).join('')}
    <span class="sub" style="margin:0 0 0 auto;font-size:12px">${esc(cur.rel)} · ${fmtSize(cur.size)}</span><button class="btn small" data-reveal="${esc(cur.path)}">Im Finder</button>`;
  const cm = v.comments.filter(c => c.file === cur.rel).sort((a, b) => a.t - b.t);
  const p = $('#player'); const dur = p && p.duration || 0;
  const mks = $('#mks'); if (mks) mks.innerHTML = dur ? cm.map(c => `<button class="mk ${c.done ? 'done' : ''}" style="left:${Math.min(100, c.t / dur * 100)}%" data-seek="${c.t}" title="${fmtTC(c.t)} ${esc(c.text)}"></button>`).join('') : '';
  const ap = v.d.approval || {}; const apThis = ap.file === cur.rel;
  const keepTxt = $('#cmt-text')?.value || ''; const hadFocus = document.activeElement?.id === 'cmt-text';
  side.innerHTML = `<form class="cmt-add" id="cmt-form"><span class="tc" id="tc">${fmtTC(p?.currentTime)}</span><input id="cmt-text" placeholder="Kommentar zu dieser Stelle, z. B. Text zu klein"><button class="btn primary small">Kommentieren</button></form>
    <div class="sec-h" style="margin:4px 0 0">Kommentare zu dieser Version<span class="r">${cm.filter(c => !c.done).length} offen</span></div>
    <div class="cmts">${cm.map(c => `<div class="cmt ${c.done ? 'done' : ''}"><button class="tcb" data-seek="${c.t}">${fmtTC(c.t)}</button><div style="min-width:0"><div class="ctx">${esc(c.text)}</div><div class="who">${esc(c.by || 'Jemand')}</div></div><input type="checkbox" data-cdone="${esc(c.id)}" ${c.done ? 'checked' : ''} aria-label="Erledigt"></div>`).join('') || '<p class="sub" style="margin:0">Noch keine Kommentare. Video an der Stelle pausieren und Feedback eintippen.</p>'}</div>
    <div class="approve"><span class="st">${apThis && ap.state === 'approved' ? `<span class="chip ok">Freigegeben</span> von ${esc(ap.by)}` : apThis && ap.state === 'changes' ? `<span class="chip rec">Änderungen nötig</span> laut ${esc(ap.by)}` : 'Wartet auf Freigabe'}</span>
      <button class="btn small danger" data-approve="changes">Änderungen nötig</button><button class="btn small ok" data-approve="approved">Freigeben</button></div>`;
  if (keepTxt || hadFocus) { const i = $('#cmt-text'); if (i) { i.value = keepTxt; if (hadFocus) i.focus(); } }
}
function postingHTML(v) {
  const c = v.client.meta || {}; const st = v.d.postState || 'entwurf'; const last = finalFile(v); const isFinal = !!(v.finals || []).length;
  const lastExport = v.exports[v.exports.length - 1];
  const acct = { instagram: c.instagram, tiktok: c.tiktok };
  return `<div class="sec-h" style="margin-top:0">1. Untertitel mit Captions<span class="r">${isFinal ? '<span class="chip ok">Final vorhanden</span>' : '<span class="chip warn">Noch ohne Untertitel</span>'}</span></div>
    <div class="fcard" data-droptarget="FINAL" style="margin-bottom:6px">
      <div class="row">
        <button class="btn small primary" data-captions="${esc(lastExport ? lastExport.path : '')}" ${lastExport ? '' : 'disabled'}>Letzten Export in Captions öffnen</button>
        <button class="btn small" data-act="final-pick">Fertige Datei als Final speichern…</button>
        <button class="btn small" data-reveal="${esc(v.path + '/FINAL')}">FINAL-Ordner</button>
      </div>
      ${(v.finals || []).length ? `<div class="flist">${v.finals.map((f, i) => `<div class="fl" draggable="true" data-drag="${esc(f.path)}"><span class="cloud l">Final ${i + 1}</span><span class="nm">${esc(f.rel)}</span><span class="sz">${fmtSize(f.size)}</span></div>`).join('')}</div>` : ''}
      <div class="note">In Captions die Untertitel setzen, exportieren und die Datei <b>hierher ziehen</b> oder über „Fertige Datei als Final speichern“ wählen. Tipp: In Captions als Speicherort direkt den FINAL-Ordner wählen, dann erscheint sie automatisch. Gepostet wird immer die neueste Final-Datei.</div>
    </div>
    <div class="sec-h">2. Posten</div>
    <div class="grid3"><label class="f">Posting-Zeitpunkt<input id="f-post" type="datetime-local" value="${esc(v.d.postAt || '')}"></label>
      <div><span class="sec-h" style="margin:0 0 6px">Status</span>${st === 'gepostet' ? '<span class="chip ok">Gepostet</span>' : st === 'geplant' ? '<span class="chip acc">In Metricool eingeplant</span>' : '<span class="chip">Entwurf</span>'}</div></div>
    ${v.d.approval?.state !== 'approved' ? '<div class="note" style="margin-bottom:12px"><b>Hinweis:</b> Die letzte Version ist noch nicht freigegeben.</div>' : ''}
    ${PLATS.map(([k, l, max]) => { const on = v.d.platforms[k] !== false; const cap = v.d.captions[k] || ''; return `<div class="platform ${on ? '' : 'off'}">
      <label class="ph"><input type="checkbox" data-plat="${k}" ${on ? 'checked' : ''}>${l}<span class="acct">${acct[k] ? esc(acct[k]) : 'Account in den Kunden-Einstellungen eintragen'}</span><span class="cnt ${cap.length > max ? 'over' : ''}" id="cnt-${k}">${cap.length}/${max}</span></label>
      ${on ? `<textarea id="cap-${k}" data-cap="${k}" placeholder="Caption und Hashtags für ${l}">${esc(cap)}</textarea><div class="row" style="margin-top:8px"><button class="btn small" data-copycap="${k}">Caption kopieren</button></div>` : ''}</div>`; }).join('')}
    <div class="sec-h">Finale Datei</div>
    ${last ? `<div class="fchip" draggable="true" data-drag="${esc(last.path)}"><span class="big exp"></span><div><b>${esc(last.rel)}</b><small>${isFinal ? 'Final mit Untertiteln' : 'Export ohne Untertitel'} · ${fmtSize(last.size)} · in Metricool oder den Browser ziehen</small></div></div>` : '<div class="note">Noch kein Export vorhanden.</div>'}
    <div class="row" style="margin-top:12px">
      ${c.metricool ? `<button class="btn primary" data-url="${esc(c.metricool)}">In Metricool planen</button>` : `<button class="btn" data-client="${esc(v.client.path)}">Metricool-Link hinterlegen</button>`}
      <button class="btn" data-post="geplant">Als eingeplant markieren</button>
      <button class="btn" data-post="gepostet">Als gepostet markieren</button>
      ${st !== 'entwurf' ? '<button class="btn" data-post="entwurf">Zurück zu Entwurf</button>' : ''}</div>
    <div class="note" style="margin-top:12px"><b>So postest du:</b> „In Metricool planen“ öffnet die Marke dieses Kunden. Dort ein neues Reel anlegen, die finale Datei hineinziehen, Caption einfügen, Zeitpunkt wählen. Metricool veröffentlicht dann auf den Accounts des Kunden. Auf dem Arbeitshandy siehst du alles in der Metricool-App.</div>`;
}

/* ---------- Dialog ---------- */
function openDialog(d) { S.dialog = { err: '', ...d }; renderDialog(); setTimeout(() => { const i = $('#dlg-root input,#dlg-root select'); i && i.focus(); i && i.select && i.select(); }, 20); }
function renderDialog() {
  const d = S.dialog; const r = $('#dlg-root');
  if (!d) { r.innerHTML = ''; return; }
  r.innerHTML = `<div class="dlg-scrim" data-act="dlg-cancel"><form class="dlg" id="dlg-form"><h3>${esc(d.title)}</h3>${d.body}${d.err ? `<div class="err">${esc(d.err)}</div>` : ''}
    <div class="acts">${d.extra || ''}<button type="button" class="btn" data-act="dlg-cancel">Abbrechen</button><button class="btn primary">${esc(d.ok || 'OK')}</button></div></form></div>`;
}
async function submitDialog() {
  const d = S.dialog; if (!d) return;
  try { const res = await d.onOk(); if (res === false) return; S.dialog = null; renderDialog(); }
  catch (e) { d.err = e.message; renderDialog(); }
}
const nameBody = (label, val, ph) => `<label class="f">${label}<input id="dlg-name" value="${esc(val || '')}" placeholder="${esc(ph || '')}" autocomplete="off"></label>`;
const dlgVal = id => ($('#' + id)?.value || '').trim();

function newVideoDialog(projectPath) {
  const projs = clients().flatMap(c => c.projects.map(p => ({ c, p })));
  if (!projs.length) { toast('Lege zuerst einen Kunden und ein Projekt an.', true); return; }
  const pre = projectPath || S.sel.p || (S.sel.c && findClient(S.sel.c)?.projects[0]?.path) || projs[0].p.path;
  openDialog({ title: 'Neues Video', ok: 'Anlegen',
    body: `<label class="f">Art<select id="dlg-type"><option value="skript">Skript-Video (mit Skript und Shotlist)</option><option value="referenz">Referenz-Video (Instagram-/TikTok-Link + Notizen)</option><option value="kreativ">Kreativ-Video (Moodboard, Drehbuch, Szenen, Canva)</option></select></label><label class="f">Projekt<select id="dlg-proj">${projs.map(({ c, p }) => `<option value="${esc(p.path)}" ${p.path === pre ? 'selected' : ''}>${esc(c.name + ' › ' + p.name)}</option>`).join('')}</select></label>${nameBody('Titel', '', 'z. B. Video 11 – Kaffee-Fehler')}`,
    onOk: async () => { const t = dlgVal('dlg-name'); if (!t) throw new Error('Bitte einen Titel eingeben.'); const p = await api.invoke('mkVideo', dlgVal('dlg-proj'), t, dlgVal('dlg-type')); await refresh(); openVideo(p); } });
}
function clientDialog(cp) {
  const c = findClient(cp); if (!c) return; const m = c.meta || {};
  openDialog({ title: 'Kunden-Einstellungen', ok: 'Speichern', clientPath: c.path,
    body: `${nameBody('Name', c.name)}<label class="f">Instagram-Account<input id="dlg-ig" value="${esc(m.instagram || '')}" placeholder="@kunde"></label>
      <label class="f">TikTok-Account<input id="dlg-tt" value="${esc(m.tiktok || '')}" placeholder="@kunde"></label>
      <label class="f">Link zur Metricool-Marke<input id="dlg-mc" value="${esc(m.metricool || '')}" placeholder="https://app.metricool.com/…"></label>
      <label class="f">Notizen<textarea id="dlg-notes" rows="3">${esc(m.notes || '')}</textarea></label>
      <div class="store-box"><b>Speicherort</b>
        ${c.external
          ? `<p>⛁ Auf Festplatte <b>„${esc(c.external.volume)}“</b>${c.external.available ? '' : ' <span class="chip rec">nicht angeschlossen</span>'}<br><span class="mono" style="font-size:11px">${esc(c.external.path)}</span></p>
             <button type="button" class="btn small" data-act="client-in" ${c.external.available ? '' : 'disabled'}>Zurück in iCloud holen</button>`
          : `<p>☁︎ In iCloud im Team-Ordner. Auf Mac und iPhone sichtbar.</p>
             <button type="button" class="btn small" data-act="client-out">Auf Festplatte verschieben …</button>`}
      </div>`,
    extra: `<button type="button" class="btn danger" data-act="del-client" style="margin-right:auto">Kunde löschen</button>`,
    onOk: async () => {
      const mc = dlgVal('dlg-mc'); if (mc && !/^https:\/\//i.test(mc)) throw new Error('Der Metricool-Link muss mit https:// beginnen.');
      await api.invoke('saveClient', c.path, { ...m, instagram: dlgVal('dlg-ig'), tiktok: dlgVal('dlg-tt'), metricool: mc, notes: $('#dlg-notes').value });
      const n = dlgVal('dlg-name'); if (n && n !== c.name) { const np = await api.invoke('rename', c.path, n); if (S.sel.c === c.path) S.sel = { c: np, p: null }; S.expanded.delete(c.path); S.expanded.add(np); saveExp(); }
      await refresh();
    } });
}
function openVideo(p) { S.open = p; S.tab = 'notiz'; S.ver = null; S.showFiles = false; S.confirmDel = false; renderDrawer(true); }
function select(sel) { S.sel = sel; if (S.view === 'set') S.view = 'over'; renderShell(); renderSide(); renderMain(); }

/* ---------- Events ---------- */
document.addEventListener('click', async e => {
  const t = e.target.closest('button,[data-act]'); if (!t) return;
  const d = t.dataset;
  if (d.act === 'dlg-cancel' && (t.tagName === 'BUTTON' || e.target === t)) { S.dialog = null; renderDialog(); return; }
  if (d.act === 'del-client') {
    const target = S.dialog && findClient(S.dialog.clientPath);
    if (!target) return;
    if (target.external) { S.dialog.err = 'Dieser Kunde liegt auf einer Festplatte. Hol ihn zuerst zurück in iCloud.'; renderDialog(); return; }
    if (target.projects.some(p => p.videos.length)) { S.dialog.err = 'Dieser Kunde hat noch Videos. Lösche oder verschiebe sie zuerst im Finder.'; renderDialog(); return; }
    await call('trash', target.path); S.dialog = null; renderDialog(); S.sel = { c: null, p: null }; refresh(); return;
  }
  // Welcome
  if (d.act === 'w-icloud') { S.cfg.root = S.icloudPath + '/Cliphaus'; $('#w-root').textContent = S.cfg.root; return; }
  if (d.act === 'w-choose' || d.act === 's-root') { const r = await call('chooseRoot'); if (r) { if (d.act === 's-root') { S.cfg = await call('setup', { root: r }); refresh(); } else { S.cfg.root = r; $('#w-root').textContent = r; } } return; }
  if (d.act === 'w-start') {
    const name = ($('#w-name')?.value || '').trim();
    if (!name) { toast('Bitte gib deinen Namen ein.', true); return; }
    if (S.cfg.root) S.cfg = await call('setup', { root: S.cfg.root, name });
    else if (S.teams.length) S.cfg = await call('setup', { name });
    else { await call('addTeam', { create: true, name: ($('#w-team')?.value || '').trim() || 'Management' }); S.cfg = await call('setup', { name }); }
    S.teams = await api.invoke('teams'); $('#app').innerHTML = ''; refresh(); return;
  }
  if (d.act === 's-name') { const n = ($('#s-name')?.value || '').trim(); if (n) { S.cfg = await call('setup', { name: n }); toast('Gespeichert'); } return; }
  if (d.view) { S.view = d.view; renderShell(); renderMain(); return; }
  if (d.act === 'sel-all') { select({ c: null, p: null }); return; }
  if (d.act === 'sel-mine') { select({ c: null, p: null, mine: true }); return; }
  if (d.act === 'team-existing') {
    const r = await call('chooseRoot'); if (!r) return;
    await call('addTeam', { root: r }); S.dialog = null; renderDialog(); await afterTeamChange(); return;
  }
  if (d.renteam) { const t = S.teams.find(x => x.id === d.renteam); if (!t) return; openDialog({ title: 'Team umbenennen', ok: 'Speichern', body: nameBody('Name', t.name), onOk: async () => { await api.invoke('renameTeam', t.id, dlgVal('dlg-name')); await afterTeamChange(true); } }); return; }
  if (d.rmteam) { await call('removeTeam', d.rmteam); toast('Aus der Liste entfernt. Der Ordner in iCloud bleibt erhalten.'); await afterTeamChange(); return; }
  if (d.act === 'assign-me') { const v = S.open && findVideo(S.open); if (v && S.cfg.name) { saveData(v, { assignee: S.cfg.name }); renderDrawer(); renderMain(); renderSide(); } return; }
  if (d.selc) { S.expanded.add(d.selc); saveExp(); select({ c: d.selc, p: null }); return; }
  if (d.selp) { const c = clients().find(c => c.projects.some(p => p.path === d.selp)); if (c) { S.expanded.add(c.path); saveExp(); } if (d.goto) S.view = d.goto; select({ c: c?.path || null, p: d.selp }); return; }
  if (d.exp) { S.expanded.has(d.exp) ? S.expanded.delete(d.exp) : S.expanded.add(d.exp); saveExp(); renderSide(); return; }
  if (d.act === 'new-client') { openDialog({ title: 'Neuer Kunde', ok: 'Anlegen', body: nameBody('Name des Kunden', '', 'z. B. Bohnenwerk Kaffee'), onOk: async () => { const p = await api.invoke('mkClient', dlgVal('dlg-name')); S.expanded.add(p); saveExp(); S.sel = { c: p, p: null }; await refresh(); setTimeout(() => projectDialog(p), 50); } }); return; }
  if (d.newp) { projectDialog(d.newp); return; }
  if (d.renp) { const p = findProject(d.renp); if (!p) return; openDialog({ title: 'Projekt umbenennen', ok: 'Speichern', body: nameBody('Name', p.name), onOk: async () => { const np = await api.invoke('rename', p.path, dlgVal('dlg-name')); if (S.sel.p === p.path) S.sel.p = np; await refresh(); } }); return; }
  if (d.client) { clientDialog(d.client); return; }
  if (d.act === 'new-video') { newVideoDialog(); return; }
  if (d.act === 'add-team') { teamDialog(); return; }
  if (d.revealTeam) { call('revealTeam', d.revealTeam).catch(() => {}); return; }
  if (d.newv) { newVideoDialog(d.newv); return; }
  if (d.cleanup) {
    const p = findProject(d.cleanup); if (!p) return;
    const files = p.videos.filter(isDone).flatMap(v => v.raw.filter(f => f.local).map(f => f.path));
    await call('evict', files); toast('Fertige RAW-Dateien vom Mac entfernt. Sie bleiben in iCloud.'); setTimeout(refresh, 1500); return;
  }
  if (d.cal) { if (d.cal === '0') S.calMonth = null; else { const b = (S.calMonth || todayStr().slice(0, 7)).split('-').map(Number); const nd = new Date(b[0], b[1] - 1 + Number(d.cal), 1); S.calMonth = nd.getFullYear() + '-' + String(nd.getMonth() + 1).padStart(2, '0'); } renderMain(); return; }
  if (d.open) { openVideo(d.open); return; }
  if (d.reveal) { call('reveal', d.reveal).catch(() => {}); return; }
  if (d.copy) { await call('copy', d.copy); toast('Pfad kopiert'); return; }
  if (d.url) { call('openUrl', d.url).catch(() => {}); return; }
  if (d.viewimg) { openLightbox(d.viewimg); return; }
  if (d.act === 'ai-open') { const v = S.open && findVideo(S.open); if (v) openAi(v); return; }
  if (d.act === 'ai-close') { if (AI.busy) api.invoke('aiCancel'); AI.open = false; renderAi(); return; }
  if (d.act === 'ai-cancel') { api.invoke('aiCancel'); return; }
  if (d.act === 'ai-check') { checkAi(); return; }
  if (d.act === 'ai-run') { runAi(); return; }
  if (d.act === 'ai-replace' || d.act === 'ai-append') {
    const v = findVideo(AI.vpath); if (!v) return;
    const text = d.act === 'ai-append' && v.d.screenplay.trim() ? v.d.screenplay.trimEnd() + '\n\n' + AI.text : AI.text;
    saveData(v, { screenplay: text }); AI.open = false; renderAi(); renderDrawer(); toast('Drehbuch übernommen.'); return;
  }
  if (d.aicopy) { await call('copy', d.aicopy); toast('Befehl kopiert. Im Terminal einfügen und Enter drücken.'); return; }
  if (d.act === 'lb-close') { $('#lb-root')?.remove(); return; }
  if (d.act === 'toggle-full') { toggleFull(); return; }
  if (d.act === 'update-install') { installUpdate(); return; }
  if (d.act === 'update-check') { const u = await checkUpdate(true); if (u && !u.available) toast(u.offline ? 'Keine Verbindung zum Update-Server.' : `Du hast die neueste Version (${u.current}).`); return; }
  if (d.act === 'client-out' || d.act === 'client-in') {
    const c = S.dialog && findClient(S.dialog.clientPath); if (!c) return;
    const out = d.act === 'client-out';
    const n = c.projects.reduce((s, p) => s + p.videos.length, 0);
    openDialog({ title: out ? `„${c.name}“ auf Festplatte verschieben?` : `„${c.name}“ zurück in iCloud holen?`, ok: out ? 'Festplatte wählen …' : 'Zurückholen',
      body: out
        ? `<p>Alle ${c.projects.length} Projekte und ${n} Videos dieses Kunden werden auf die Festplatte kopiert und geprüft. <b>Erst danach</b> wird die Kopie in iCloud entfernt (30 Tage unter icloud.com → „Zuletzt gelöscht“ wiederherstellbar).</p>
           <p>Danach: nur sichtbar, wenn die Festplatte am Mac hängt. Auf dem iPhone erscheint der Kunde grau. <b>Kein iCloud-Backup mehr</b>, mach ab und zu eine zweite Kopie.</p>`
        : `<p>Alles wird von „${esc(c.external.volume)}“ zurück in iCloud kopiert und geprüft. Danach wird es von der Festplatte entfernt. Der Mac braucht dafür genug freien Speicher, iCloud lädt im Hintergrund hoch.</p>`,
      onOk: async () => { S.dialog = null; renderDialog(); await runMove(c, out); return false; } });
    return;
  }
  if (d.act === 'refresh') { refresh(); return; }
  if (d.act === 'close') { S.open = null; renderDrawer(); return; }
  const v = S.open && findVideo(S.open); if (!v) return;
  if (d.tab) { S.tab = d.tab; renderDrawer(); return; }
  if (d.stage) { saveData(v, { stage: d.stage }); renderDrawer(); renderMain(); return; }
  if (d.vtype) { saveData(v, { type: d.vtype }); renderDrawer(); renderMain(); return; }
  if (d.captions) { call('openInCaptions', d.captions).then(() => toast('Captions wird geöffnet …')).catch(() => {}); return; }
  if (d.act === 'final-pick') { const fs = await call('pickFiles', { kind: 'video', multi: false }); if (fs.length) { await call('importFiles', v.path, 'FINAL', fs); toast('Als Final gespeichert.'); refresh(); } return; }
  if (d.act === 'mood-pick') { const fs = await call('pickFiles', { kind: 'image', multi: true }); if (fs.length) { await call('importFiles', v.path, 'MOODBOARD', fs); refresh(); } return; }
  if (d.rmfile) { await call('removeFile', d.rmfile); refresh(); return; }
  if (d.rmcolor) { const colors = v.d.moodboard.colors.filter((_, i) => i !== +d.rmcolor); saveData(v, { moodboard: { ...v.d.moodboard, colors } }); renderDrawer(); return; }
  if (d.act === 'sc-add') { saveData(v, { scenes: [...v.d.scenes, { id: Date.now().toString(36), title: '', ort: '', shot: '', brennweite: '', dauer: '', text: '', ton: '' }] }); renderDrawer(); setTimeout(() => $('#sc-' + (v.d.scenes.length - 1) + '-title')?.focus(), 0); return; }
  if (d.scdel) { const sc = [...v.d.scenes]; sc.splice(+d.scdel, 1); saveData(v, { scenes: sc }); renderDrawer(); return; }
  if (d.scmove) { const [i, dir] = d.scmove.split(':').map(Number); const j = i + dir; const sc = [...v.d.scenes]; if (j < 0 || j >= sc.length) return; [sc[i], sc[j]] = [sc[j], sc[i]]; saveData(v, { scenes: sc }); renderDrawer(); return; }
  if (d.sceneimg !== undefined) { const fs = await call('pickFiles', { kind: 'image', multi: false }); if (fs.length) await setSceneImage(v, +d.sceneimg, fs[0]); return; }

  if (d.delref) { const refs = [...v.d.references]; refs.splice(+d.delref, 1); saveData(v, { references: refs }); renderDrawer(); return; }
  if (d.delshot) { const shots = [...v.d.shots]; shots.splice(+d.delshot, 1); saveData(v, { shots }); renderDrawer(); return; }
  if (d.act === 'files') { S.showFiles = !S.showFiles; renderDrawer(); return; }
  if (d.dl) { S.busy = 'iCloud lädt die Dateien auf deinen Mac…'; renderDrawer(); await call('download', v.raw.filter(f => !f.local).map(f => f.path)).catch(() => {}); S.busy = ''; setTimeout(refresh, 1500); return; }
  if (d.dlfile) { await call('download', [d.dlfile]).catch(() => {}); toast('Wird geladen…'); setTimeout(refresh, 2000); return; }
  if (d.evict) { await call('evict', v.raw.filter(f => f.local).map(f => f.path)).catch(() => {}); toast('Vom Mac entfernt. Die Dateien bleiben in iCloud.'); setTimeout(refresh, 1500); return; }
  if (d.ver) { S.ver = d.ver; renderDrawer(); return; }
  if (d.seek) { const p = $('#player'); if (p) { p.currentTime = +d.seek; p.pause(); } return; }
  if (d.approve) { const cur = currentVersion(v); if (!cur) return; saveData(v, { approval: { state: d.approve, file: cur.rel, by: S.cfg.name, at: new Date().toISOString() }, stage: d.approve === 'approved' ? 'frei' : 'schnitt' }); renderDrawer(); renderMain(); return; }
  if (d.post) { const patch = { postState: d.post }; if (d.post === 'gepostet') patch.stage = 'gepostet'; saveData(v, patch); renderDrawer(); renderMain(); return; }
  if (d.copycap) { await call('copy', v.d.captions[d.copycap] || ''); toast('Caption kopiert'); return; }
  if (d.act === 'del') { S.confirmDel = true; renderDrawer(); return; }
  if (d.act === 'del-no') { S.confirmDel = false; renderDrawer(); return; }
  if (d.act === 'del-yes') { await call('trash', v.path); S.open = null; S.confirmDel = false; refresh(); return; }
});
function teamDialog() {
  openDialog({ title: 'Team hinzufügen', ok: 'Team anlegen',
    body: `${nameBody('Name des neuen Teams', '', 'z. B. ACD Management oder Persönlich')}
      <label class="f">Wo speichern?<select id="dlg-loc">
        <option value="icloud">iCloud Drive (mit Team teilbar, auch auf dem iPhone)</option>
        <option value="mac">Nur auf diesem Mac (Dokumente)</option>
        <option value="choose">Selbst wählen … (z. B. externe Festplatte)</option></select></label>
      <div class="note"><b>iCloud:</b> Teilen über Finder → Rechtsklick → Teilen. Auf dem iPhone sichtbar.<br><b>Mac oder Festplatte:</b> nur für dich, nicht auf dem iPhone. Ist die Festplatte nicht angeschlossen, ist das Team ausgegraut.<br><br>Wurdest du eingeladen oder hast schon einen Ordner? Dann „Vorhandenen Ordner wählen…“.</div>`,
    extra: `<button type="button" class="btn" data-act="team-existing" style="margin-right:auto">Vorhandenen Ordner wählen…</button>`,
    onOk: async () => { const id = await api.invoke('addTeam', { create: true, name: dlgVal('dlg-name'), location: dlgVal('dlg-loc') }); if (!id) return false; await afterTeamChange(); } });
}
async function afterTeamChange(keepSel) {
  const st = await api.invoke('state');
  S.cfg = st.cfg || {}; S.teams = st.teams || [];
  if (!keepSel) { S.sel = { c: null, p: null }; S.open = null; renderDrawer(); }
  S.tree = st.tree; normalize(S.tree);
  renderShell(); renderSide(); renderMain();
  refresh();
}
async function setSceneImage(v, i, src, quiet) {
  const ext = (src.match(/\.[a-z0-9]+$/i) || ['.png'])[0].toLowerCase();
  if (!v.d.scenes[i].id) v.d.scenes[i].id = Date.now().toString(36);
  const name = v.d.scenes[i].id + '-' + Date.now().toString(36) + ext;
  await call('importAs', v.path, 'STORYBOARD', src, name);
  const old = v.d.scenes[i] && v.d.scenes[i].img;
  const sc = v.d.scenes.map((x, k) => k === i ? { ...x, img: name } : x);
  saveData(v, { scenes: sc });
  if (old) { const f = v.storyboard.find(x => x.rel === old); if (f) api.invoke('removeFile', f.path).catch(() => {}); }
  if (!quiet) refresh();
}
/* ---------- Lokale KI: Drehbuch aus Shots ---------- */
const AI = { open: false, busy: false, text: '', err: '', status: null, vpath: null };
api.onAiChunk(t => {
  if (!AI.busy) return;
  AI.text = t;
  const o = $('#ai-out'); if (o) { o.textContent = cleanAi(t); o.scrollTop = o.scrollHeight; }
});
const cleanAi = t => String(t || '').replace(/^```[a-z]*\s*/i, '').replace(/```\s*$/, '').trim();
function modelInstalled(st) {
  if (!st || !st.models) return false;
  const want = st.model.includes(':') ? st.model : st.model + ':latest';
  return st.models.some(n => n === st.model || n === want);
}
function aiPrompt(v) {
  const me = S.cfg.name || 'die Person, die schreibt';
  const system = `Du bist ein erfahrener Drehbuchautor für kurze, cinematische Social-Media-Videos. Du bekommst eine Shot-Liste mit Notizen und schreibst daraus ein sauberes Drehbuch auf Deutsch.
Regeln:
- Nutze nur, was in den Shots steht. Erfinde keine neuen Ereignisse, Orte oder Figuren. Kurze Übergänge sind erlaubt.
- "Ich" oder "mich" in den Notizen ist ${me}. Andere Personen heißen so, wie sie in den Notizen genannt werden (z. B. BRUDER).
- Fasse aufeinanderfolgende Shots am gleichen Ort zu einer Szene zusammen. Szenenkopf: SZENE <Nr> – INNEN oder AUSSEN – <ORT> – <TAGESZEIT>. Lass unbekannte Teile weg.
- Handlung im Präsens, knapp und bildhaft.
- Kamera-Angaben (Einstellung, Brennweite) als kurze Regieanweisung in Klammern, z. B. (Halbnah, 35 mm).
- Dialog: Figurenname in GROSSBUCHSTABEN in eigener Zeile, darunter der Satz. Sätze aus den Notizen übernehmen, nur Rechtschreibung und Satzzeichen korrigieren.
- Musik, Sound und Voice-over als Regieanweisung.
- Antworte nur mit dem Drehbuch. Keine Einleitung, keine Erklärung, kein Markdown.`;
  const shots = v.d.scenes.map((sc, i) => {
    const cam = [sc.shot, sc.brennweite ? sc.brennweite + ' mm' : '', sc.dauer ? sc.dauer + ' s' : ''].filter(Boolean).join(', ');
    return [`Shot ${String(i + 1).padStart(2, '0')}: ${sc.title || 'ohne Titel'}`,
      sc.ort ? `Ort: ${sc.ort}` : '', cam ? `Kamera: ${cam}` : '',
      sc.text ? `Was passiert: ${sc.text}` : '', sc.ton ? `Dialog/Ton: ${sc.ton}` : ''].filter(Boolean).join('\n');
  }).join('\n\n');
  const mood = v.d.moodboard && v.d.moodboard.notes ? `Stimmung/Look: ${v.d.moodboard.notes}\n` : '';
  return { system, prompt: `Titel des Videos: ${v.d.title}\n${mood}\nShots:\n${shots}` };
}
async function checkAi() {
  AI.status = await api.invoke('aiStatus').catch(() => ({ running: false, model: 'gemma3:12b' }));
  AI.err = ''; renderAi();
  if (AI.status.running && modelInstalled(AI.status) && !AI.text && !AI.busy) runAi();
}
async function openAi(v) {
  AI.open = true; AI.vpath = v.path; AI.text = ''; AI.err = ''; AI.status = null;
  renderAi(); await checkAi();
}
async function runAi() {
  const v = findVideo(AI.vpath); if (!v || AI.busy) return;
  AI.busy = true; AI.text = ''; AI.err = ''; renderAi();
  try { AI.text = cleanAi(await api.invoke('aiGenerate', aiPrompt(v))); }
  catch (e) { AI.err = e.message; }
  AI.busy = false; renderAi();
}
function renderAi() {
  let root = $('#ai-root');
  if (!AI.open) { root?.remove(); return; }
  if (!root) { root = document.createElement('div'); root.id = 'ai-root'; document.body.appendChild(root); }
  const st = AI.status; const v = findVideo(AI.vpath);
  let body = '', foot = '';
  if (!st) body = '<p class="sub">Prüfe lokale KI …</p>';
  else if (!st.running) {
    body = `<div class="ai-help"><b>Die lokale KI läuft gerade nicht.</b><ol>
      <li>Ist <b>Ollama</b> installiert? Sonst kostenlos laden: <button class="linkbtn" data-url="https://ollama.com/download">ollama.com/download</button></li>
      <li>Die App <b>Ollama</b> öffnen (Lama-Symbol oben in der Menüleiste).</li>
      <li>Dann hier auf „Erneut prüfen“.</li></ol></div>`;
    foot = '<button class="btn primary" data-act="ai-check">Erneut prüfen</button>';
  } else if (!modelInstalled(st)) {
    const cmd = 'ollama pull ' + st.model;
    body = `<div class="ai-help"><b>Das Sprachmodell fehlt noch.</b><p>Öffne das <b>Terminal</b>, füge diesen Befehl ein und drück Enter. Der Download ist einmalig etwa 8 GB.</p>
      <div class="pathrow"><code>${esc(cmd)}</code><button class="btn small" data-aicopy="${esc(cmd)}">Kopieren</button></div>
      ${st.models && st.models.length ? `<p>Oder nimm ein Modell, das schon da ist:</p><select id="ai-model-pick">${st.models.map(n => `<option>${esc(n)}</option>`).join('')}</select>` : ''}</div>`;
    foot = '<button class="btn primary" data-act="ai-check">Erneut prüfen</button>';
  } else {
    body = `<div class="ai-out" id="ai-out">${AI.text ? esc(cleanAi(AI.text)) : AI.busy ? '<span class="sub">Die KI liest deine Shots und schreibt … (10–40 Sekunden)</span>' : ''}</div>${AI.err ? `<div class="err">${esc(AI.err)}</div>` : ''}`;
    const hasOld = v && v.d.screenplay.trim();
    foot = AI.busy ? '<button class="btn" data-act="ai-cancel">Abbrechen</button>'
      : `${AI.text ? `<button class="btn primary" data-act="ai-replace">${hasOld ? 'Drehbuch ersetzen' : 'Übernehmen'}</button>${hasOld ? '<button class="btn" data-act="ai-append">Unten anhängen</button>' : ''}` : ''}<button class="btn" data-act="ai-run">${AI.text || AI.err ? 'Nochmal' : 'Starten'}</button>`;
  }
  root.innerHTML = `<div class="ai-scrim"><div class="ai-panel">
    <div class="ai-h"><b>✨ Drehbuch aus Shots</b>${st && st.running ? `<span class="chip ok">lokal · ${esc(st.model)}</span>` : ''}<button class="x" data-act="ai-close" aria-label="Schließen">×</button></div>
    <div class="ai-body">${body}</div>
    <div class="ai-foot"><span class="sub" style="margin:0 auto 0 0;font-size:12px">Läuft komplett auf deinem Mac. Nichts wird hochgeladen.</span>${foot}</div></div></div>`;
  const o = $('#ai-out'); if (o) o.scrollTop = o.scrollHeight;
}
async function loadAiSettings() {
  const box = $('#ai-settings'); if (!box) return;
  const st = await api.invoke('aiStatus').catch(() => ({ running: false, model: 'gemma3:12b' }));
  if (!$('#ai-settings')) return;
  box.innerHTML = st.running
    ? `<p><span class="chip ok">Ollama läuft</span> ${modelInstalled(st) ? `Modell <b>${esc(st.model)}</b> ist bereit.` : `Modell <b>${esc(st.model)}</b> fehlt noch: im Terminal <code>ollama pull ${esc(st.model)}</code>`}</p>
       ${st.models && st.models.length ? `<label class="f">Modell<select id="ai-model">${[...new Set([st.model, ...st.models])].map(n => `<option ${n === st.model ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>` : ''}`
    : `<p><span class="chip rec">Ollama läuft nicht</span> Öffne die App „Ollama“, dann diese Seite neu öffnen.</p>`;
}
// Bilder von Shots/Moodboard, die nur in iCloud liegen, automatisch auf den Mac laden
const dlRequested = new Set();
function autoDownloadImages(v) {
  if (!isKreativ(v) || !onICloud()) return;
  const todo = [...(v.storyboard || []), ...(v.moodboard || [])].filter(f => !f.local && !dlRequested.has(f.path));
  if (!todo.length) return;
  todo.forEach(f => dlRequested.add(f.path));
  api.invoke('download', todo.map(f => f.path)).then(() => setTimeout(refresh, 2500)).catch(() => {});
}
api.onMoveProgress(t => { const el = $('#move-text'); if (el && t) el.textContent = t; });
async function runMove(c, out) {
  const root = document.createElement('div'); root.id = 'move-root';
  root.innerHTML = `<div class="ai-scrim"><div class="ai-panel" style="width:min(520px,100%)"><div class="ai-h"><b>${out ? '⛁ Auf Festplatte verschieben' : '☁︎ Zurück in iCloud'}</b></div>
    <div class="ai-body" style="min-height:0"><p><b>${esc(c.name)}</b></p><p id="move-text" class="sub">Starte …</p><p class="sub" style="font-size:12px">Bitte Cliphaus offen lassen und die Festplatte nicht abziehen.</p></div></div></div>`;
  document.body.appendChild(root);
  try {
    const r = await api.invoke(out ? 'moveClientOut' : 'moveClientIn', c.path);
    if (r) toast(out ? `Verschoben: ${r.files} Dateien auf „${r.volume}“.` : `Zurückgeholt: ${r.files} Dateien in iCloud.`);
  } catch (e) { toast(e.message, true); }
  root.remove();
  S.open = null; renderDrawer(); refresh();
}
/* ---------- Updates ---------- */
let UPD = null;
async function checkUpdate(manual) {
  UPD = await api.invoke('updateCheck').catch(() => null);
  const b = $('#upd-btn');
  if (b && UPD && UPD.available) { b.hidden = false; b.textContent = `⬆︎ Update ${UPD.latest} installieren`; b.title = UPD.notes || ''; }
  const v = $('#ver-line'); if (v && UPD) v.textContent = `Version ${UPD.current}` + (UPD.available ? ` · Update ${UPD.latest} verfügbar` : UPD.manual ? ` · Version ${UPD.latest} muss einmal von Hand installiert werden` : ' · aktuell');
  return UPD;
}
api.onUpdateProgress(t => { const b = $('#upd-btn'); if (b) b.textContent = t; });
async function installUpdate() {
  if (!UPD || !UPD.available) return;
  const b = $('#upd-btn'); if (b) b.disabled = true;
  try { await api.invoke('updateInstall'); } catch (e) { toast(e.message, true); if (b) { b.disabled = false; b.textContent = `⬆︎ Update ${UPD.latest} installieren`; } }
}
setTimeout(() => checkUpdate(), 4000);
setInterval(() => checkUpdate(), 6 * 3600 * 1000);
function toggleFull() {
  S.full = !S.full;
  try { localStorage.setItem('drawerFull', S.full ? '1' : ''); } catch {}
  const dr = $('.drawer'); if (dr) dr.classList.toggle('full', S.full);
  const v = S.open && findVideo(S.open); if (v) $('#dr-head').innerHTML = headHTML(v);
}
function openLightbox(p) {
  $('#lb-root')?.remove();
  const el = document.createElement('div');
  el.id = 'lb-root'; el.className = 'lightbox'; el.dataset.act = 'lb-close';
  el.innerHTML = `<img src="${esc(api.fileUrl(p))}?t=${Date.now()}" alt=""><button class="x lb-x" data-act="lb-close" aria-label="Schließen">×</button>`;
  document.body.appendChild(el);
}
function projectDialog(cp) {
  openDialog({ title: 'Neues Projekt', ok: 'Anlegen', body: nameBody('Name des Projekts', '', 'z. B. November 2026'),
    onOk: async () => {
      const c = findClient(cp);
      if (c && c.external && !c.external.available) throw new Error('Die Festplatte dieses Kunden ist nicht angeschlossen.');
      const p = await api.invoke('mkProject', (c && c.dataPath) || cp, dlgVal('dlg-name')); S.expanded.add(cp); saveExp(); S.sel = { c: cp, p }; await refresh();
    } });
}
document.addEventListener('submit', e => {
  e.preventDefault();
  if (e.target.id === 'dlg-form') { submitDialog(); return; }
  const v = S.open && findVideo(S.open); if (!v) return;
  if (e.target.id === 'ref-form') {
    const url = $('#ref-new').value.trim();
    if (!/^https?:\/\//i.test(url)) { toast('Bitte einen vollständigen Link einfügen, der mit https:// beginnt.', true); return; }
    saveData(v, { references: [...v.d.references, { url: url.replace(/^http:/i, 'https:'), note: '', addedBy: S.cfg.name || '', at: new Date().toISOString() }] });
    renderDrawer(); setTimeout(() => $('#ref-note-' + (v.d.references.length - 1))?.focus(), 0); return;
  }
  if (e.target.id === 'shot-form') { const txt = $('#shot-new').value.trim(); if (!txt) return; saveData(v, { shots: [...v.d.shots, { text: txt, done: false }] }); renderDrawer(); setTimeout(() => $('#shot-new')?.focus(), 0); }
  if (e.target.id === 'cmt-form') {
    const txt = $('#cmt-text').value.trim(); const cur = currentVersion(v); if (!txt || !cur) return;
    const c = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), file: cur.rel, t: Math.round(($('#player')?.currentTime || 0) * 10) / 10, text: txt, by: S.cfg.name, at: new Date().toISOString(), done: false };
    v.comments.push(c); $('#cmt-text').value = ''; call('saveComment', v.path, c).catch(() => {}); renderReviewSide(v);
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'q') { S.q = t.value; renderMain(); return; }
  const v = S.open && findVideo(S.open); if (!v) return;
  if (t.id === 'f-title') saveData(v, { title: t.value }, 500);
  else if (t.id === 'f-script') saveData(v, { script: t.value }, 700);
  else if (t.id === 'f-notes') saveData(v, { notes: t.value }, 700);
  else if (t.id === 'f-screenplay') saveData(v, { screenplay: t.value }, 700);
  else if (t.id === 'mb-notes') saveData(v, { moodboard: { ...v.d.moodboard, notes: t.value } }, 700);
  else if (t.dataset.scf && t.tagName !== 'SELECT') { const i = +t.dataset.sc, f = t.dataset.scf; saveData(v, { scenes: v.d.scenes.map((x, k) => k === i ? { ...x, [f]: t.value } : x) }, 600); }
  else if (t.dataset.refnote !== undefined) { const refs = v.d.references.map((r, i) => i === +t.dataset.refnote ? { ...r, note: t.value } : r); saveData(v, { references: refs }, 700); }
  else if (t.dataset.cap) { const k = t.dataset.cap; saveData(v, { captions: { ...v.d.captions, [k]: t.value } }, 600); const max = PLATS.find(p => p[0] === k)[2]; const c = $('#cnt-' + k); if (c) { c.textContent = t.value.length + '/' + max; c.classList.toggle('over', t.value.length > max); } }
});
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'ai-model' || t.id === 'ai-model-pick') {
    await call('aiSetModel', t.value); toast('Modell: ' + t.value);
    if (t.id === 'ai-model-pick') checkAi(); else loadAiSettings();
    return;
  }
  if (t.id === 'team-sel') {
    if (t.value === '__add') { t.value = S.cfg.active || ''; teamDialog(); return; }
    await call('switchTeam', t.value); await afterTeamChange(); return;
  }
  const v = S.open && findVideo(S.open); if (!v) return;
  if (t.id === 'f-title') {
    const title = t.value.trim(); if (!title) return; saveData(v, { title });
    try { const np = await api.invoke('rename', v.path, title); if (np !== v.path) { S.open = np; await refresh(); } } catch (err) { toast(err.message, true); }
  }
  else if (t.dataset.orphan !== undefined && t.value !== '') {
    const i = +t.value; const rel = t.dataset.orphan;
    saveData(v, { scenes: v.d.scenes.map((x, k) => k === i ? { ...x, img: rel } : x) }); renderDrawer(); toast('Bild zu Shot ' + String(i + 1).padStart(2, '0') + ' zugeordnet.');
  }
  else if (t.id === 'mb-color') { saveData(v, { moodboard: { ...v.d.moodboard, colors: [...v.d.moodboard.colors, t.value] } }); renderDrawer(); }
  else if (t.id === 'canva-link') { saveData(v, { canva: t.value.trim() }); renderDrawer(); }
  else if (t.dataset.scf && t.tagName === 'SELECT') { const i = +t.dataset.sc; saveData(v, { scenes: v.d.scenes.map((x, k) => k === i ? { ...x, shot: t.value } : x) }); }
  else if (t.id === 'f-shoot') { saveData(v, { shootDate: t.value }); renderMain(); }
  else if (t.id === 'f-due') { saveData(v, { dueDate: t.value }); renderMain(); }
  else if (t.id === 'f-assignee') { saveData(v, { assignee: t.value.trim() }); renderMain(); }
  else if (t.id === 'f-post') { saveData(v, { postAt: t.value }); renderMain(); }
  else if (t.dataset.shot !== undefined) {
    const shots = v.d.shots.map((s, i) => i === +t.dataset.shot ? { ...s, done: t.checked } : s); const patch = { shots };
    if (shots.length && shots.every(s => s.done) && (IX[v.d.stage] ?? 0) < IX.dreh) patch.stage = 'dreh';
    saveData(v, patch); renderDrawer(); renderMain();
  }
  else if (t.dataset.plat) { saveData(v, { platforms: { ...v.d.platforms, [t.dataset.plat]: t.checked } }); renderDrawer(); }
  else if (t.dataset.cdone) { const c = v.comments.find(x => x.id === t.dataset.cdone); if (c) { c.done = t.checked; call('saveComment', v.path, c).catch(() => {}); renderReviewSide(v); } }
});
document.addEventListener('keydown', e => {
  if (e.metaKey && e.shiftKey && (e.key === 'f' || e.key === 'F') && S.open) { e.preventDefault(); toggleFull(); return; }
  if (e.key !== 'Escape') return;
  if ($('#lb-root')) { $('#lb-root').remove(); return; }
  if (AI.open) { if (AI.busy) api.invoke('aiCancel'); AI.open = false; renderAi(); return; }
  if (S.dialog) { S.dialog = null; renderDialog(); return; }
  if (S.open) { S.open = null; renderDrawer(); }
});

/* Drag: Ordner/Dateien aus Cliphaus in CapCut/DaVinci, Karten im Board, Dateien in RAW */
let dragCard = null;
document.addEventListener('dragstart', e => {
  const out = e.target.closest && e.target.closest('[data-drag]');
  if (out) { e.preventDefault(); api.drag([out.dataset.drag]); return; }
  const card = e.target.closest && e.target.closest('[data-card]');
  if (card) { dragCard = card.dataset.card; e.dataTransfer.effectAllowed = 'move'; }
});
document.addEventListener('dragover', e => {
  const col = e.target.closest && e.target.closest('.col');
  if (col && dragCard) { e.preventDefault(); document.querySelectorAll('.col.drop').forEach(x => x !== col && x.classList.remove('drop')); col.classList.add('drop'); return; }
  if (e.target.closest && e.target.closest('[data-scenedrop]') && e.dataTransfer.types.includes('Files')) { e.preventDefault(); return; }
  const tgt = e.target.closest && e.target.closest('[data-droptarget]');
  if (tgt && e.dataTransfer.types.includes('Files')) { e.preventDefault(); tgt.classList.add('on'); }
});
document.addEventListener('dragleave', e => { const tgt = e.target.closest && e.target.closest('[data-droptarget]'); if (tgt && !tgt.contains(e.relatedTarget)) tgt.classList.remove('on'); });
document.addEventListener('drop', async e => {
  const col = e.target.closest && e.target.closest('.col');
  if (col && dragCard) { e.preventDefault(); const v = findVideo(dragCard); if (v) saveData(v, { stage: col.dataset.col }); dragCard = null; renderMain(); return; }
  const scd = e.target.closest && e.target.closest('[data-scenedrop]');
  if (scd && e.dataTransfer.files.length) {
    e.preventDefault(); const v = S.open && findVideo(S.open); if (!v) return;
    const p = api.pathFor(e.dataTransfer.files[0]); if (p) await setSceneImage(v, +scd.dataset.scenedrop, p);
    return;
  }
  const tgt = e.target.closest && e.target.closest('[data-droptarget]');
  if (tgt) {
    e.preventDefault(); tgt.classList.remove('on');
    const v = S.open && findVideo(S.open); if (!v) return;
    const paths = [...e.dataTransfer.files].map(f => api.pathFor(f)).filter(Boolean);
    if (!paths.length) return;
    const where = tgt.dataset.droptarget;
    S.busy = `Kopiert ${paths.length} Element${paths.length > 1 ? 'e' : ''} in ${where}… (große Dateien brauchen einen Moment)`; renderDrawer();
    try { await api.invoke('importFiles', v.path, where, paths); toast(where === 'FINAL' ? 'Als Final gespeichert.' : where === 'MOODBOARD' ? 'Ins Moodboard gelegt.' : 'In RAW abgelegt.' + (onICloud() ? ' iCloud lädt im Hintergrund hoch.' : '')); } catch (err) { toast('Kopieren fehlgeschlagen: ' + err.message, true); }
    S.busy = ''; refresh();
  }
});
document.addEventListener('dragend', () => { dragCard = null; document.querySelectorAll('.col.drop').forEach(x => x.classList.remove('drop')); });

/* ---------- Boot ---------- */
(async () => {
  try {
    const st = await api.invoke('state');
    S.cfg = st.cfg || {}; S.teams = st.teams || []; S.icloud = st.icloud; S.icloudPath = st.icloudPath;
    S.tree = st.tree; normalize(S.tree);
  } catch (e) { toast(e.message, true); }
  renderShell();
  if (S.cfg.root && S.cfg.name) refresh();
})();
})();
